import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import jwt from "jsonwebtoken";

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || "cogniwake-super-secret-key-9988";

function generateToken(user: any) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

const app = express();
app.use(express.json());
const PORT = 3000;

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.warn("GEMINI_API_KEY is not set or is using placeholder. Falling back to local generative mock mode.");
    return null;
  }
  if (!aiClient) {
    try {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    } catch (e) {
      console.error("Failed to initialize GoogleGenAI client:", e);
      return null;
    }
  }
  return aiClient;
}

interface DBUser {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'coach';
  difficulty: 'easy' | 'medium' | 'hard';
  snoozeLimit: number;
  avatarUrl: string;
}

interface DBAlarm {
  id: string;
  userId: string;
  time: string;
  days: string[];
  isActive: boolean;
  challengeType: 'math' | 'memory' | 'sequence' | 'word' | 'reaction' | 'logic' | 'stroop';
  difficulty: 'easy' | 'medium' | 'hard';
  sound: string;
}

// In-memory Database for demo sessions
const dbState = {
  users: [
    {
      id: "demo-user-1",
      name: "Alex Rivera",
      email: "alex@cogniwake.com",
      role: "user" as const,
      difficulty: "medium" as const,
      snoozeLimit: 3,
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    },
    {
      id: "demo-user-2",
      name: "Coach Sarah",
      email: "sarah@cogniwake.com",
      role: "coach" as const,
      difficulty: "hard" as const,
      snoozeLimit: 1,
      avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    }
  ] as DBUser[],
  alarms: [
    {
      id: "alarm-1",
      userId: "demo-user-1",
      time: "06:30",
      days: ["Weekdays"],
      isActive: true,
      challengeType: "math" as const,
      difficulty: "medium" as const,
      sound: "chime",
    },
    {
      id: "alarm-2",
      userId: "demo-user-1",
      time: "08:30",
      days: ["Weekends"],
      isActive: false,
      challengeType: "memory" as const,
      difficulty: "easy" as const,
      sound: "ambient",
    }
  ] as DBAlarm[],
  performanceLogs: [
    { date: "2026-07-02", accuracy: 72, completionRate: 85, snoozesCount: 2, timeToSolve: 42 },
    { date: "2026-07-03", accuracy: 80, completionRate: 90, snoozesCount: 1, timeToSolve: 35 },
    { date: "2026-07-04", accuracy: 75, completionRate: 88, snoozesCount: 2, timeToSolve: 38 },
    { date: "2026-07-05", accuracy: 85, completionRate: 95, snoozesCount: 0, timeToSolve: 28 },
    { date: "2026-07-06", accuracy: 90, completionRate: 100, snoozesCount: 0, timeToSolve: 24 },
    { date: "2026-07-07", accuracy: 84, completionRate: 92, snoozesCount: 1, timeToSolve: 26 },
  ],
  coachRecommendations: [
    {
      id: "rec-1",
      userId: "demo-user-1",
      coachName: "Coach Sarah",
      text: "Try 15 mins of light math before your deep logic puzzles to improve speed and cognitive wakefulness.",
      applied: false,
      date: "2026-07-07",
    }
  ],
  clients: [
    {
      id: "demo-user-1",
      name: "Alex Rivera",
      email: "alex@cogniwake.com",
      habitScore: 84,
      streak: 12,
      snoozeReduction: 35,
      accuracy: 81,
      alarmsCount: 2,
    },
    {
      id: "client-2",
      name: "Jordan Smith",
      email: "jordan@gmail.com",
      habitScore: 92,
      streak: 19,
      snoozeReduction: 50,
      accuracy: 89,
      alarmsCount: 1,
    },
    {
      id: "client-3",
      name: "Taylor Wu",
      email: "taylor.wu@yahoo.com",
      habitScore: 64,
      streak: 3,
      snoozeReduction: 10,
      accuracy: 68,
      alarmsCount: 3,
    }
  ]
};

// ---------------- API Routes ----------------

// Authentication Endpoints
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = dbState.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (user) {
    const token = generateToken(user);
    return res.json({ success: true, user: { ...user, token } });
  }
  // Allow dynamic registration on login if they just put in details
  const newUser = {
    id: `user-${Date.now()}`,
    name: email.split("@")[0].charAt(0).toUpperCase() + email.split("@")[0].slice(1),
    email,
    role: (email.includes("coach") ? "coach" : "user") as "user" | "coach",
    difficulty: "medium" as const,
    snoozeLimit: 3,
    avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"
  };
  dbState.users.push(newUser);
  const token = generateToken(newUser);
  res.json({ success: true, user: { ...newUser, token } });
});

app.post("/api/auth/register", (req, res) => {
  const { name, email, role, difficulty } = req.body;
  const existing = dbState.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    const token = generateToken(existing);
    return res.json({ success: true, user: { ...existing, token } });
  }
  const newUser = {
    id: `user-${Date.now()}`,
    name: name || "New User",
    email,
    role: (role || "user") as "user" | "coach",
    difficulty: (difficulty || "medium") as "easy" | "medium" | "hard",
    snoozeLimit: 3,
    avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"
  };
  dbState.users.push(newUser);
  const token = generateToken(newUser);
  res.json({ success: true, user: { ...newUser, token } });
});

// OAuth2 Google simulation endpoint
app.post("/api/auth/oauth-simulate", (req, res) => {
  const { email, name, role } = req.body;
  const targetEmail = email || "google-pilot@gmail.com";
  const targetName = name || "Google Pilot";
  
  let user = dbState.users.find(u => u.email.toLowerCase() === targetEmail.toLowerCase());
  if (!user) {
    user = {
      id: `google-user-${Date.now()}`,
      name: targetName,
      email: targetEmail,
      role: (role || "user") as "user" | "coach",
      difficulty: "medium" as const,
      snoozeLimit: 3,
      avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"
    };
    dbState.users.push(user);
  }
  const token = generateToken(user);
  res.json({ success: true, user: { ...user, token } });
});

// Update Profile settings
app.put("/api/auth/profile", (req, res) => {
  const { difficulty, snoozeLimit } = req.body;
  // In our demo we have a single logged in user alex rivera / google pilot
  const user = dbState.users[0]; // default to first demo user
  if (user) {
    if (difficulty) user.difficulty = difficulty;
    if (snoozeLimit !== undefined) user.snoozeLimit = snoozeLimit;
    return res.json(user);
  }
  res.status(404).json({ error: "User not found" });
});

// Alarms Endpoints
app.get("/api/alarms", (req, res) => {
  res.json(dbState.alarms);
});

app.post("/api/alarms", (req, res) => {
  const { time, days, challengeType, difficulty, sound } = req.body;
  const newAlarm = {
    id: `alarm-${Date.now()}`,
    userId: "demo-user-1",
    time: time || "07:00",
    days: days || ["Weekdays"],
    isActive: true,
    challengeType: (challengeType || "math") as "math" | "memory" | "sequence" | "word" | "reaction" | "logic" | "stroop",
    difficulty: (difficulty || "medium") as "easy" | "medium" | "hard",
    sound: sound || "chime"
  };
  dbState.alarms.push(newAlarm);
  res.json(newAlarm);
});

app.put("/api/alarms/:id", (req, res) => {
  const { id } = req.params;
  const { isActive, time, days, challengeType, difficulty, sound } = req.body;
  const index = dbState.alarms.findIndex(a => a.id === id);
  if (index !== -1) {
    dbState.alarms[index] = {
      ...dbState.alarms[index],
      ...(isActive !== undefined && { isActive }),
      ...(time !== undefined && { time }),
      ...(days !== undefined && { days }),
      ...(challengeType !== undefined && { challengeType }),
      ...(difficulty !== undefined && { difficulty }),
      ...(sound !== undefined && { sound })
    };
    return res.json(dbState.alarms[index]);
  }
  res.status(404).json({ error: "Alarm not found" });
});

app.delete("/api/alarms/:id", (req, res) => {
  const { id } = req.params;
  const index = dbState.alarms.findIndex(a => a.id === id);
  if (index !== -1) {
    dbState.alarms.splice(index, 1);
    return res.json({ success: true });
  }
  res.status(404).json({ error: "Alarm not found" });
});

// Performance Data
app.get("/api/performance", (req, res) => {
  res.json(dbState.performanceLogs);
});

app.post("/api/performance/log", (req, res) => {
  const { accuracy, snoozesCount, timeToSolve } = req.body;
  const today = new Date().toISOString().split("T")[0];
  const newLog = {
    date: today,
    accuracy: Number(accuracy) || 100,
    completionRate: 100,
    snoozesCount: Number(snoozesCount) || 0,
    timeToSolve: Number(timeToSolve) || 30
  };
  
  // Find if log for today already exists
  const existingIndex = dbState.performanceLogs.findIndex(l => l.date === today);
  if (existingIndex !== -1) {
    // Average or update
    dbState.performanceLogs[existingIndex].accuracy = Math.round((dbState.performanceLogs[existingIndex].accuracy + newLog.accuracy) / 2);
    dbState.performanceLogs[existingIndex].snoozesCount += newLog.snoozesCount;
    dbState.performanceLogs[existingIndex].timeToSolve = Math.round((dbState.performanceLogs[existingIndex].timeToSolve + newLog.timeToSolve) / 2);
  } else {
    dbState.performanceLogs.push(newLog);
    if (dbState.performanceLogs.length > 7) {
      dbState.performanceLogs.shift();
    }
  }
  res.json({ success: true, log: newLog });
});

// Coach Recommendations
app.get("/api/coach/recommendations", (req, res) => {
  res.json(dbState.coachRecommendations);
});

app.post("/api/coach/recommendations", (req, res) => {
  const { text } = req.body;
  const newRec = {
    id: `rec-${Date.now()}`,
    userId: "demo-user-1",
    coachName: "Coach Sarah",
    text: text || "Avoid screens for 30 minutes before bed to optimize sleep patterns.",
    applied: false,
    date: new Date().toISOString().split("T")[0]
  };
  dbState.coachRecommendations.push(newRec);
  res.json(newRec);
});

app.post("/api/coach/recommendations/:id/apply", (req, res) => {
  const { id } = req.params;
  const index = dbState.coachRecommendations.findIndex(r => r.id === id);
  if (index !== -1) {
    dbState.coachRecommendations[index].applied = true;
    return res.json(dbState.coachRecommendations[index]);
  }
  res.status(404).json({ error: "Recommendation not found" });
});

app.get("/api/coach/clients", (req, res) => {
  res.json(dbState.clients);
});

// ----------------- AI Puzzles Generator using Gemini -----------------

// Fallback Generators if Gemini is missing
const fallbackPuzzles: Record<string, (diff: string) => any> = {
  math: (diff) => {
    if (diff === "easy") {
      const a = Math.floor(Math.random() * 10) + 5;
      const b = Math.floor(Math.random() * 10) + 5;
      return {
        id: `fb-m-${Date.now()}`,
        type: "math",
        question: `Solve: ${a} + ${b}`,
        options: [String(a+b), String(a+b-2), String(a+b+3), String(a+b-1)].sort(() => Math.random() - 0.5),
        correctAnswer: String(a+b),
        hint: "Simple addition",
        explanation: "Add the two numbers together."
      };
    } else if (diff === "hard") {
      const a = Math.floor(Math.random() * 12) + 6;
      const b = Math.floor(Math.random() * 8) + 4;
      const c = Math.floor(Math.random() * 20) + 10;
      return {
        id: `fb-m-${Date.now()}`,
        type: "math",
        question: `Solve: (${a} * ${b}) - ${c}`,
        options: [String(a*b-c), String(a*b-c+10), String(a*b-c-5), String(a*b-c+15)].sort(() => Math.random() - 0.5),
        correctAnswer: String(a*b-c),
        hint: "Multiply first, then subtract",
        explanation: `${a} multiplied by ${b} is ${a*b}, then subtract ${c} to get ${a*b-c}.`
      };
    } else {
      const a = Math.floor(Math.random() * 15) + 5;
      const b = Math.floor(Math.random() * 15) + 5;
      return {
        id: `fb-m-${Date.now()}`,
        type: "math",
        question: `Solve: ${a} * ${b}`,
        options: [String(a*b), String(a*b-10), String(a*b+15), String(a*b+5)].sort(() => Math.random() - 0.5),
        correctAnswer: String(a*b),
        hint: "Double digit multiplication",
        explanation: "Calculate the product."
      };
    }
  },
  memory: (diff) => {
    const sequences = {
      easy: {
        seq: "Yellow, Blue, Blue, Yellow",
        q: "What is the 3rd color in the sequence?",
        ans: "Blue",
        opts: ["Yellow", "Blue", "Green", "Red"]
      },
      medium: {
        seq: "Magenta, Teal, Orange, Teal, Magenta",
        q: "Which color was repeated in the 2nd and 4th position?",
        ans: "Teal",
        opts: ["Magenta", "Teal", "Orange", "Red"]
      },
      hard: {
        seq: "Circle, Square, Triangle, Square, Circle, Triangle",
        q: "What is the shape sequence from 4th to 6th position?",
        ans: "Square, Circle, Triangle",
        opts: ["Square, Circle, Triangle", "Circle, Square, Triangle", "Square, Triangle, Circle", "Triangle, Square, Circle"]
      }
    };
    const s = sequences[diff as "easy" | "medium" | "hard"] || sequences.medium;
    return {
      id: `fb-me-${Date.now()}`,
      type: "memory",
      question: `Memorize this sequence: "${s.seq}". \n\n${s.q}`,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Recall the spatial positions",
      explanation: `The full sequence is ${s.seq}.`
    };
  },
  sequence: (diff) => {
    const seqs = {
      easy: {
        q: "Find the next number: 2, 4, 8, 16, __",
        ans: "32",
        opts: ["24", "30", "32", "36"],
        expl: "Each term is multiplied by 2."
      },
      medium: {
        q: "Complete the sequence: 1, 4, 9, 16, 25, __",
        ans: "36",
        opts: ["30", "35", "36", "49"],
        expl: "These are the squares of consecutive integers: 1^2, 2^2, 3^2, 4^2, 5^2, 6^2."
      },
      hard: {
        q: "Find the missing number: 2, 3, 5, 8, 13, 21, __",
        ans: "34",
        opts: ["28", "30", "34", "38"],
        expl: "This is the Fibonacci sequence: each term is the sum of the preceding two."
      }
    };
    const s = seqs[diff as "easy" | "medium" | "hard"] || seqs.medium;
    return {
      id: `fb-s-${Date.now()}`,
      type: "sequence",
      question: s.q,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Look at the pattern of differences",
      explanation: s.expl
    };
  },
  word: (diff) => {
    const words = {
      easy: {
        q: "Unscramble this sleep-related word: 'E E L S P'",
        ans: "SLEEP",
        opts: ["PEELS", "SLEEP", "KEEPS", "PEELS"],
        expl: "S-L-E-E-P is the unscrambled word."
      },
      medium: {
        q: "Which word means 'to be fully awake and attentive'?",
        ans: "ALERT",
        opts: ["ALIVE", "ALERT", "SLEEPY", "TIRED"],
        expl: "ALERT means fully awake and attentive."
      },
      hard: {
        q: "Unscramble the word: 'G O C I N I T I V E'",
        ans: "COGNITIVE",
        opts: ["COGNITIVE", "CONTAGIOUS", "COGNIZANT", "COLLECTIVE"],
        expl: "C-O-G-N-I-T-I-V-E is the correct spelling."
      }
    };
    const s = words[diff as "easy" | "medium" | "hard"] || words.medium;
    return {
      id: `fb-w-${Date.now()}`,
      type: "word",
      question: s.q,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Relates to the brain and morning",
      explanation: s.expl
    };
  },
  reaction: (diff) => {
    const reactions = {
      easy: {
        q: "Reaction Response: Quickly press the button that corresponds to 'YELLOW' written in YELLOW color.",
        ans: "YELLOW",
        opts: ["YELLOW", "BLUE", "GREEN", "RED"],
        expl: "The prompt asked for 'YELLOW' when written in yellow color."
      },
      medium: {
        q: "Reaction Speed: A flash signal displays 'Go!' at index 3. Count how many times 'Go!' appeared in this sequence: [Stop, Stop, Go!, Stop, Go!]",
        ans: "2",
        opts: ["1", "2", "3", "4"],
        expl: "The word 'Go!' appeared twice in the sequence."
      },
      hard: {
        q: "Reaction Test: Tap the button corresponding to the highest frequency wave: 450Hz, 220Hz, 880Hz, or 110Hz.",
        ans: "880Hz",
        opts: ["880Hz", "450Hz", "220Hz", "110Hz"],
        expl: "880Hz is the highest frequency of the listed options."
      }
    };
    const s = reactions[diff as "easy" | "medium" | "hard"] || reactions.medium;
    return {
      id: `fb-r-${Date.now()}`,
      type: "reaction",
      question: s.q,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Respond to the exact keyword",
      explanation: s.expl
    };
  },
  logic: (diff) => {
    const logics = {
      easy: {
        q: "If all A are B, and all B are C, are all A necessarily C?",
        ans: "Yes",
        opts: ["Yes", "No", "Depends", "None"],
        expl: "Yes, by transitivity, if A is a subset of B, and B is a subset of C, then A is a subset of C."
      },
      medium: {
        q: "Five people are in a room. You shake hands with everyone else once. How many total handshakes occur?",
        ans: "10",
        opts: ["5", "10", "15", "20"],
        expl: "Using the formula n*(n-1)/2: 5*4/2 = 10 handshakes."
      },
      hard: {
        q: "A farmer has 17 sheep. All but 9 die. How many sheep are left alive?",
        ans: "9",
        opts: ["8", "9", "17", "0"],
        expl: "'All but 9 die' means exactly 9 sheep are left alive."
      }
    };
    const s = logics[diff as "easy" | "medium" | "hard"] || logics.medium;
    return {
      id: `fb-l-${Date.now()}`,
      type: "logic",
      question: s.q,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Read the logic or wording carefully",
      explanation: s.expl
    };
  },
  stroop: (diff) => {
    const stroops = {
      easy: {
        q: "Stroop Test: Select the actual font color of the word: 'GREEN' written in RED text.",
        ans: "RED",
        opts: ["GREEN", "RED", "BLUE", "BLACK"],
        expl: "The font color is RED, although the letters spell 'GREEN'."
      },
      medium: {
        q: "Stroop Test: Select the actual font color of the word: 'YELLOW' written in BLUE text.",
        ans: "BLUE",
        opts: ["YELLOW", "BLUE", "GREEN", "RED"],
        expl: "The font color is BLUE."
      },
      hard: {
        q: "Stroop Test: Select the actual font color of the word: 'BLACK' written in ORANGE text.",
        ans: "ORANGE",
        opts: ["BLACK", "ORANGE", "WHITE", "PURPLE"],
        expl: "The font color is ORANGE."
      }
    };
    const s = stroops[diff as "easy" | "medium" | "hard"] || stroops.medium;
    return {
      id: `fb-st-${Date.now()}`,
      type: "stroop",
      question: s.q,
      options: s.opts,
      correctAnswer: s.ans,
      hint: "Ignore the word spelling and look at the actual color",
      explanation: s.expl
    };
  }
};

app.post("/api/challenges/generate", async (req, res) => {
  const { type, difficulty } = req.body;
  const challengeType = type || "math";
  const diff = difficulty || "medium";

  const ai = getGeminiClient();
  if (!ai) {
    // Generate fallback puzzle
    const puzzle = fallbackPuzzles[challengeType] ? fallbackPuzzles[challengeType](diff) : fallbackPuzzles.math(diff);
    return res.json(puzzle);
  }

  try {
    const prompt = `Generate a wake-up brain challenge of type "${challengeType}" with difficulty level "${diff}".
The response MUST be a single JSON object. Do not wrap it in markdown. Do not include any text before or after the JSON.
The JSON object must match this schema:
{
  "id": "string (a unique random string id)",
  "type": "string (one of: 'math', 'memory', 'sequence', 'word', 'reaction', 'logic', 'stroop')",
  "question": "string (a clear, engaging question to wake someone up. If math, standard arithmetic. If sequence, complete a number pattern. If memory, a short colorful sequence to recall. If word, an anagram. If reaction, a speed keyword match query. If logic, a clever syllogism riddle. If stroop, a color-word conflict visual query)",
  "options": ["array of exactly 4 strings for multiple choice options containing the correct answer and three plausible distractors"],
  "correctAnswer": "string (exactly matching one of the options)",
  "hint": "string (a useful short clue)",
  "explanation": "string (explanation of the solution)"
}

Example for Math Medium:
{
  "id": "ai-m-12345",
  "type": "math",
  "question": "Calculate: (12 * 4) + 15",
  "options": ["48", "63", "58", "61"],
  "correctAnswer": "63",
  "hint": "Perform the multiplication in the parentheses first",
  "explanation": "12 times 4 is 48. Adding 15 gives 63."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            type: { type: Type.STRING },
            question: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            correctAnswer: { type: Type.STRING },
            hint: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ["id", "type", "question", "options", "correctAnswer", "hint", "explanation"]
        }
      }
    });

    const text = response.text?.trim() || "";
    const cleanJson = text.replace(/^```json/, "").replace(/```$/, "").trim();
    const puzzle = JSON.parse(cleanJson);
    res.json(puzzle);
  } catch (error) {
    console.error("Error generating puzzle with Gemini, falling back:", error);
    const puzzle = fallbackPuzzles[challengeType] ? fallbackPuzzles[challengeType](diff) : fallbackPuzzles.math(diff);
    res.json(puzzle);
  }
});

// Sleep Insights Endpoint
app.get("/api/insights", async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) {
    return res.json({
      insight: "Try 15 mins of light math before your deep logic puzzles to improve speed and cognitive wakefulness.",
      tip: "Avoid snoozing! Each snooze interrupts your sleep cycle again, compounding sleep inertia."
    });
  }

  try {
    const prompt = `Give me a single highly scientific sleep/wake cognitive tip for people struggle with sleep inertia (difficulty waking up).
The output should be a JSON object with two fields:
{
  "insight": "A customized 1-2 sentence recommendation for improving cognitive wakefulness",
  "tip": "A short, actionable micro-habit to apply tonight"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insight: { type: Type.STRING },
            tip: { type: Type.STRING }
          },
          required: ["insight", "tip"]
        }
      }
    });

    const text = response.text?.trim() || "";
    const cleanJson = text.replace(/^```json/, "").replace(/```$/, "").trim();
    const insights = JSON.parse(cleanJson);
    res.json(insights);
  } catch (error) {
    console.error("Gemini insights generation error, returning fallback:", error);
    res.json({
      insight: "Light exposure in the first 10 minutes of waking suppresses melatonin and resets your circadian clock naturally.",
      tip: "Place your phone on the other side of the room to force yourself to get out of bed to solve the CogniWake challenge."
    });
  }
});


// Serve static assets or mount Vite dev server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
