-- finalized Relational Database Schema for CogniWake
-- PostgreSQL / SQLite / MySQL Compatible

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'coach')),
    difficulty VARCHAR(20) DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
    snooze_limit INT DEFAULT 3,
    avatar_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create email index for lightning fast lookups during authentication
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- 2. Alarms Table
CREATE TABLE IF NOT EXISTS alarms (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    time VARCHAR(5) NOT NULL, -- Format: "HH:MM"
    days TEXT[] NOT NULL, -- e.g., ['Monday', 'Tuesday']
    is_active BOOLEAN DEFAULT TRUE,
    challenge_type VARCHAR(20) DEFAULT 'math' CHECK (challenge_type IN ('math', 'memory', 'sequence', 'word', 'reaction', 'logic', 'stroop')),
    difficulty VARCHAR(20) DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
    sound VARCHAR(50) DEFAULT 'chime',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index for scheduled scans
CREATE INDEX IF NOT EXISTS idx_alarms_schedule ON alarms(time, is_active);

-- 3. Performance Logs Table
CREATE TABLE IF NOT EXISTS performance_logs (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    accuracy INT NOT NULL, -- Percent (0 - 100)
    snoozes_count INT NOT NULL,
    time_to_solve INT NOT NULL, -- in seconds
    challenge_type VARCHAR(20),
    difficulty VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_performance_user ON performance_logs(user_id);

-- 4. Coach Recommendations Table
CREATE TABLE IF NOT EXISTS coach_recommendations (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    coach_name VARCHAR(100) NOT NULL,
    text TEXT NOT NULL,
    applied BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 5. Challenge Bank Table (Seed Bank)
CREATE TABLE IF NOT EXISTS challenge_bank (
    id VARCHAR(50) PRIMARY KEY,
    type VARCHAR(20) NOT NULL,
    difficulty VARCHAR(20) NOT NULL,
    question TEXT NOT NULL,
    options TEXT[] NOT NULL,
    correct_answer VARCHAR(255) NOT NULL,
    hint TEXT,
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- -----------------------------------------------------------------------------
-- Seed Initial Challenges Bank (Milestone 2 Seeding)
-- -----------------------------------------------------------------------------

INSERT INTO challenge_bank (id, type, difficulty, question, options, correct_answer, hint, explanation) VALUES
-- Math Seeds
('seed-math-e1', 'math', 'easy', 'Calculate: 8 + 14 - 5', ARRAY['15', '17', '18', '21'], '17', 'Add 8 and 14 first', '8 + 14 = 22, and 22 - 5 = 17.'),
('seed-math-m1', 'math', 'medium', 'Calculate: (15 * 3) - 12', ARRAY['30', '33', '45', '48'], '33', 'Do multiplication first', '15 * 3 = 45. 45 - 12 = 33.'),
('seed-math-h1', 'math', 'hard', 'Solve for x: 3x - 7 = 5x - 19', ARRAY['4', '6', '12', '14'], '6', 'Bring x to one side', 'Subtract 3x: 2x - 19 = -7, so 2x = 12, x = 6.'),

-- Memory Seeds
('seed-mem-e1', 'memory', 'easy', 'Recall this sequence of colors: RED -> BLUE -> RED. What was the 2nd color?', ARRAY['RED', 'BLUE', 'GREEN', 'YELLOW'], 'BLUE', 'The sequence of colors was short', 'RED, BLUE, RED. The second is BLUE.'),
('seed-mem-m1', 'memory', 'medium', 'Recall this sequence: YELLOW -> GREEN -> RED -> BLUE. What was the 3rd color?', ARRAY['YELLOW', 'GREEN', 'RED', 'BLUE'], 'RED', 'Third item in the four-item chain', 'RED is at index 3 in YELLOW, GREEN, RED, BLUE.'),

-- Sequence Seeds
('seed-seq-e1', 'sequence', 'easy', 'Identify the next number: 2, 4, 6, 8, ?', ARRAY['9', '10', '11', '12'], '10', 'Count up by 2s', 'Add 2 to 8 to get 10.'),
('seed-seq-m1', 'sequence', 'medium', 'Identify the next number: 3, 6, 12, 24, ?', ARRAY['30', '36', '48', '50'], '48', 'Each number doubles', '24 * 2 = 48.'),

-- Word Seeds
('seed-word-e1', 'word', 'easy', 'Unscramble the morning word: ' || quote_literal('EKAW'), ARRAY['WAKE', 'WEAK', 'KNEW', 'WAVE'], 'WAKE', 'Opposite of sleep', 'Unscrambling E-K-A-W yields WAKE.'),
('seed-word-m1', 'word', 'medium', 'Which of these is an anagram of ' || quote_literal('SNOOZE') || '?', ARRAY['ZENOSOS', 'SNOOZED', 'ZONERS', 'OOSENZ'], 'OOSENZ', 'Use the exact same letters', 'O-O-S-E-N-Z contains exactly the same letters as SNOOZE.'),

-- Reaction Seeds
('seed-react-e1', 'reaction', 'easy', 'Reaction Test: Tap ' || quote_literal('YELLOW') || ' only if background is yellow.', ARRAY['YELLOW', 'RED', 'GREEN', 'BLUE'], 'YELLOW', 'Match the requested color word', 'Yellow word matches.'),

-- Logic Seeds
('seed-logic-e1', 'logic', 'easy', 'If all A are B, and all B are C, are all A necessarily C?', ARRAY['Yes', 'No', 'Depends', 'None'], 'Yes', 'Subset transitivity', 'A is inside B which is inside C.'),

-- Stroop Seeds
('seed-stroop-e1', 'stroop', 'easy', 'Select the actual font color of the word: ' || quote_literal('GREEN') || ' written in RED text.', ARRAY['GREEN', 'RED', 'BLUE', 'BLACK'], 'RED', 'Observe the pixel color, ignore the letters', 'The actual font text is colored RED.');
