export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'coach';
  avatarUrl?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  snoozeLimit: number;
}

export interface Alarm {
  id: string;
  time: string; // "HH:MM"
  days: string[]; // ["Monday", "Tuesday", ...] or ["Weekdays", "Weekends"]
  isActive: boolean;
  challengeType: 'math' | 'memory' | 'sequence' | 'word' | 'reaction' | 'logic' | 'stroop';
  difficulty: 'easy' | 'medium' | 'hard';
  sound: string; // "chime", "radar", "digital", "ambient"
}

export interface Puzzle {
  id: string;
  type: 'math' | 'memory' | 'sequence' | 'word' | 'reaction' | 'logic' | 'stroop';
  question: string;
  options: string[];
  correctAnswer: string;
  hint?: string;
  explanation?: string;
}

export interface PerformanceLog {
  date: string; // "YYYY-MM-DD"
  accuracy: number; // 0-100
  completionRate: number; // 0-100
  snoozesCount: number;
  timeToSolve: number; // seconds
}

export interface CoachRecommendation {
  id: string;
  coachName: string;
  text: string;
  applied: boolean;
  date: string;
}

export interface ClientData {
  id: string;
  name: string;
  email: string;
  habitScore: number;
  streak: number;
  snoozeReduction: number;
  accuracy: number;
  alarmsCount: number;
}
