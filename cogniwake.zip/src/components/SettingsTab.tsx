import { useState } from "react";
import { User, Shield, UserCheck, Bell, Sparkles, Sliders } from "lucide-react";
import { User as UserType } from "../types";

interface SettingsTabProps {
  user: UserType;
  onUpdateUser: (updated: Partial<UserType>) => void;
}

export default function SettingsTab({ user, onUpdateUser }: SettingsTabProps) {
  const [difficulty, setDifficulty] = useState(user.difficulty);
  const [snoozeLimit, setSnoozeLimit] = useState(user.snoozeLimit);
  const [coachConsent, setCoachConsent] = useState(true);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    onUpdateUser({
      difficulty,
      snoozeLimit,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto flex flex-col gap-8">
      {/* Profile Card */}
      <div className="glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col sm:flex-row items-center gap-5 relative overflow-hidden">
        <div className="absolute top-[-30%] right-[-10%] w-48 h-48 bg-[#005ac2]/10 rounded-full blur-[60px] pointer-events-none"></div>

        <img
          src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"}
          alt={user.name}
          className="w-20 h-20 rounded-full border-2 border-[#adc6ff] object-cover shadow-lg"
        />
        <div className="text-center sm:text-left">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-1.5 justify-center sm:justify-start">
            <h3 className="text-xl font-bold font-display text-white">{user.name}</h3>
            <span className="px-2.5 py-0.5 rounded bg-blue-500/10 text-[#adc6ff] border border-blue-500/20 text-[10px] font-mono font-bold uppercase tracking-wider w-fit mx-auto sm:mx-0">
              {user.role === "coach" ? "Wellness Coach" : "Standard User"}
            </span>
          </div>
          <p className="text-xs text-[#c2c6d6] font-mono mb-1">{user.email}</p>
          <span className="text-[11px] text-slate-400 font-light block">Registered Member ID: {user.id}</span>
        </div>
      </div>

      {/* Settings Options Form */}
      <div className="glass-card rounded-2xl p-6 md:p-8 border border-[#424754]/20 flex flex-col gap-6">
        <div>
          <h3 className="text-md font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#adc6ff]" /> COGNITIVE ADJUSTMENTS
          </h3>
          <p className="text-xs text-[#c2c6d6] mt-1">Adjust default alarm settings to calibrate sleep inertia suppression.</p>
        </div>

        {/* Global Challenge Difficulty */}
        <div className="flex flex-col gap-2.5">
          <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#adc6ff]" /> Default Challenge Difficulty
          </label>
          <div className="flex gap-2">
            {(["easy", "medium", "hard"] as const).map((diff) => (
              <button
                key={diff}
                onClick={() => setDifficulty(diff)}
                className={`flex-1 py-3 px-4 rounded-xl border text-xs font-bold uppercase transition-all cursor-pointer ${
                  difficulty === diff
                    ? "bg-[#005ac2]/20 border-[#adc6ff] text-[#adc6ff] shadow-inner"
                    : "bg-[#1c2026]/40 border-[#424754]/40 text-[#c2c6d6] hover:bg-[#353940]/30"
                }`}
              >
                {diff}
              </button>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 font-light italic leading-relaxed">
            Easy utilizes basic arithmetic or short visual sequences. Hard utilizes progressive logic puzzles and multi-digit math generated in real-time by the Gemini model.
          </p>
        </div>

        {/* Snooze Limits */}
        <div className="flex flex-col gap-2.5">
          <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider flex items-center gap-1">
            <Bell className="w-3.5 h-3.5 text-[#d0bcff]" /> Max Snooze Threshold
          </label>
          <select
            value={snoozeLimit}
            onChange={(e) => setSnoozeLimit(Number(e.target.value))}
            className="bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3 text-white text-sm focus:border-[#adc6ff] focus:outline-none transition-colors"
          >
            <option value={1}>1 snooze (Extreme Wakefulness Mode)</option>
            <option value={2}>2 snoozes (Balanced Challenge)</option>
            <option value={3}>3 snoozes (Standard Threshold)</option>
            <option value={5}>5 snoozes (Lenient Habit Builder)</option>
          </select>
        </div>

        {/* Coach Consent Link */}
        <div className="flex items-center gap-3 py-3 px-4 bg-[#161b22]/50 border border-[#424754]/20 rounded-xl">
          <input
            type="checkbox"
            id="coachConsent"
            checked={coachConsent}
            onChange={(e) => setCoachConsent(e.target.checked)}
            className="w-4 h-4 rounded border-slate-700 bg-[#1c2026] text-blue-500 focus:ring-0 cursor-pointer"
          />
          <div className="flex-1">
            <label htmlFor="coachConsent" className="text-xs font-bold text-white block cursor-pointer select-none">
              Connect to Sleep Coach Sarah
            </label>
            <span className="text-[10px] text-[#c2c6d6] block font-light leading-relaxed">
              Enables Coach Sarah to see your progress logs and submit customized wake routines or cognitive suggestions.
            </span>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-4 border-t border-[#424754]/10">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Shield className="w-4 h-4" />
            <span>Encrypted local storage profile</span>
          </div>

          <div className="flex items-center gap-3">
            {saveSuccess && (
              <span className="text-xs font-mono font-bold text-emerald-400 animate-fade-in flex items-center gap-1">
                <UserCheck className="w-4 h-4" /> Config saved!
              </span>
            )}
            <button
              onClick={handleSave}
              className="energy-gradient-bg hover:opacity-95 text-white font-bold text-sm px-8 py-3 rounded-xl transition-all shadow-lg shadow-[#005ac2]/10 cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
