import { useState, useEffect } from "react";
import { 
  Home, Clock, Brain, TrendingUp, Settings, LogOut, Sparkles, 
  ChevronRight, Calendar, AlertCircle, FileText, CheckCircle, Activity
} from "lucide-react";
import { User, Alarm, PerformanceLog, CoachRecommendation } from "../types";
import AlarmsTab from "./AlarmsTab";
import CognitiveLabsTab from "./CognitiveLabsTab";
import PerformanceTab from "./PerformanceTab";
import SettingsTab from "./SettingsTab";

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onSimulateAlarm: (alarm: Alarm) => void;
  alarms: Alarm[];
  onToggleAlarm: (id: string, isActive: boolean) => void;
  onAddAlarm: (alarm: Omit<Alarm, "id" | "isActive">) => void;
  onDeleteAlarm: (id: string) => void;
  onUpdateUser: (updatedFields: Partial<User>) => void;
}

export default function Dashboard({
  user,
  onLogout,
  onSimulateAlarm,
  alarms,
  onToggleAlarm,
  onAddAlarm,
  onDeleteAlarm,
  onUpdateUser,
}: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'alarms' | 'labs' | 'performance' | 'settings'>('overview');
  const [logs, setLogs] = useState<PerformanceLog[]>([]);
  const [coachRecs, setCoachRecs] = useState<CoachRecommendation[]>([]);
  const [aiInsight, setAiInsight] = useState<{ insight: string; tip: string } | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  // Dynamic greeting based on current hour
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
  };

  // Fetch performance logs and coach recommendations on mount
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const perfRes = await fetch("/api/performance");
        const perfData = await perfRes.json();
        setLogs(perfData);

        const coachRes = await fetch("/api/coach/recommendations");
        const coachData = await coachRes.json();
        setCoachRecs(coachData);
      } catch (err) {
        console.error("Failed to load dashboard data:", err);
      }
    };

    fetchDashboardData();
  }, [activeTab]);

  // Lazy load AI Insights when Overview tab is active
  useEffect(() => {
    if (activeTab !== "overview" || aiInsight) return;
    const fetchAiInsight = async () => {
      setLoadingInsight(true);
      try {
        const res = await fetch("/api/insights");
        const data = await res.json();
        setAiInsight(data);
      } catch (err) {
        console.error("Failed to fetch AI insights:", err);
      } finally {
        setLoadingInsight(false);
      }
    };
    fetchAiInsight();
  }, [activeTab, aiInsight]);

  const handleApplyRecommendation = async (id: string) => {
    try {
      await fetch(`/api/coach/recommendations/${id}/apply`, { method: "POST" });
      setCoachRecs(prev => prev.map(r => r.id === id ? { ...r, applied: true } : r));
    } catch (err) {
      console.error(err);
    }
  };

  // Find next active alarm
  const nextAlarm = alarms.find(a => a.isActive);

  return (
    <div className="bg-[#0A0E14] text-[#dfe2eb] min-h-screen font-sans flex select-none">
      
      {/* Desktop Sidebar */}
      <aside className="w-64 bg-[#10141a]/95 border-r border-[#424754]/20 hidden lg:flex flex-col justify-between p-6 fixed top-0 bottom-0 z-40">
        <div className="flex flex-col gap-8">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('overview')}>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
              <Brain className="w-5.5 h-5.5 text-[#adc6ff]" />
            </div>
            <span className="font-display text-xl font-extrabold text-white tracking-tight">CogniWake</span>
          </div>

          {/* Profile Quick Glance */}
          <div className="flex items-center gap-3 p-3 bg-[#161b22]/40 rounded-2xl border border-[#424754]/10">
            <img
              src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150"}
              alt={user.name}
              className="w-10 h-10 rounded-full object-cover border border-[#adc6ff]/40"
            />
            <div className="overflow-hidden">
              <span className="font-bold text-xs text-white block truncate">{user.name}</span>
              <span className="text-[10px] font-mono text-slate-400 block truncate">{user.email}</span>
            </div>
          </div>

          {/* Tab Selection */}
          <nav className="flex flex-col gap-1.5">
            {[
              { id: 'overview' as const, label: 'Overview', icon: <Home className="w-4 h-4" /> },
              { id: 'alarms' as const, label: 'Alarms Schedule', icon: <Clock className="w-4 h-4" /> },
              { id: 'labs' as const, label: 'Cognitive Labs', icon: <Brain className="w-4 h-4" /> },
              { id: 'performance' as const, label: 'Performance', icon: <TrendingUp className="w-4 h-4" /> },
              { id: 'settings' as const, label: 'Preferences', icon: <Settings className="w-4 h-4" /> },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full py-3 px-4 rounded-xl font-bold text-sm text-left flex items-center gap-3.5 transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-[#005ac2] to-[#571bc1] text-white shadow-lg shadow-blue-500/5"
                    : "text-[#c2c6d6] hover:bg-[#161b22] hover:text-white"
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>

          {/* New Alarm CTA Button */}
          <button
            onClick={() => {
              setActiveTab('alarms');
            }}
            className="w-full bg-[#1c2026] text-[#adc6ff] border border-blue-500/20 hover:bg-[#005ac2]/10 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer mt-2"
          >
            Create New Wake Circle
          </button>
        </div>

        {/* Footer actions */}
        <button
          onClick={onLogout}
          className="w-full py-3 px-4 rounded-xl font-bold text-xs text-slate-400 hover:text-white hover:bg-red-500/10 hover:text-red-400 transition-all flex items-center gap-3 cursor-pointer"
        >
          <LogOut className="w-4 h-4" /> Sign Out of App
        </button>
      </aside>

      {/* Main Content wrapper */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        
        {/* Mobile Navigation Header */}
        <header className="bg-[#10141a] border-b border-[#424754]/20 p-4 flex justify-between items-center lg:hidden sticky top-0 z-40">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
              <Brain className="w-5 h-5 text-[#adc6ff]" />
            </div>
            <span className="font-display text-lg font-black text-white">CogniWake</span>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={activeTab}
              onChange={(e) => setActiveTab(e.target.value as any)}
              className="bg-[#1c2026] border border-[#424754]/50 rounded-lg text-xs font-semibold px-2.5 py-1.5 text-[#dfe2eb] focus:outline-none"
            >
              <option value="overview">Overview</option>
              <option value="alarms">Alarms</option>
              <option value="labs">Labs</option>
              <option value="performance">Performance</option>
              <option value="settings">Settings</option>
            </select>

            <button
              onClick={onLogout}
              className="p-1.5 bg-red-500/10 text-red-400 rounded-lg"
              title="Sign Out"
            >
              <LogOut className="w-4.5 h-4.5" />
            </button>
          </div>
        </header>

        {/* Content body space */}
        <main className="p-6 md:p-12 overflow-y-auto no-scrollbar flex-1 max-w-7xl mx-auto w-full flex flex-col gap-8">
          
          {/* Section Header */}
          {activeTab === 'overview' && (
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-[#424754]/10">
              <div>
                <h1 className="text-3xl font-black font-display text-white tracking-tight flex items-center gap-2">
                  {getGreeting()}, <span className="energy-gradient-text">{user.name.split(" ")[0]}!</span>
                </h1>
                <p className="text-sm text-[#c2c6d6] font-light mt-1">Here is your customized morning cognitive readiness overview.</p>
              </div>

              {/* Action Report download */}
              <button className="text-[#adc6ff] font-mono text-[11px] font-bold tracking-wider hover:underline flex items-center gap-1.5 cursor-pointer">
                <FileText className="w-4 h-4" /> EXPORT INSIGHT REPORT
              </button>
            </header>
          )}

          {/* Overview Content Grid (Bento Box style) */}
          {activeTab === 'overview' && (
            <div className="flex flex-col gap-8 animate-fade-in">
              {/* Bento Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* 1. Habit Score Progress Card (5 columns) */}
                <div className="md:col-span-5 glass-card rounded-3xl p-6 border border-[#424754]/20 flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute top-[-20%] left-[-10%] w-36 h-36 bg-[#005ac2]/10 rounded-full blur-[50px] pointer-events-none"></div>
                  
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Your Habit Score</span>
                    <span className="text-[10px] font-bold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase">CRITICAL LINE</span>
                  </div>

                  <div className="flex flex-col items-center gap-4 my-auto">
                    {/* SVG circular progress */}
                    <div className="relative w-36 h-36 flex items-center justify-center select-none">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="72" cy="72" r="60" stroke="#1c2026" strokeWidth="8" fill="transparent" />
                        <circle
                          cx="72"
                          cy="72"
                          r="60"
                          stroke="url(#progressGradient)"
                          strokeWidth="8"
                          fill="transparent"
                          strokeDasharray={2 * Math.PI * 60}
                          strokeDashoffset={2 * Math.PI * 60 * (1 - 84 / 100)}
                          strokeLinecap="round"
                        />
                        <defs>
                          <linearGradient id="progressGradient" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stopColor="#005ac2" />
                            <stop offset="100%" stopColor="#571bc1" />
                          </linearGradient>
                        </defs>
                      </svg>
                      <div className="absolute flex flex-col items-center">
                        <span className="text-4xl font-extrabold font-display text-white">84</span>
                        <span className="text-[10px] uppercase font-mono font-bold text-[#c2c6d6] tracking-wider">EXCELLENT</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 text-center border-t border-[#424754]/10 pt-4 mt-6 gap-2">
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Consistency</span>
                      <h5 className="text-sm font-bold text-[#adc6ff] mt-0.5">92%</h5>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Puzzle Win</span>
                      <h5 className="text-sm font-bold text-[#d0bcff] mt-0.5">81%</h5>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Snooze Cut</span>
                      <h5 className="text-sm font-bold text-emerald-400 mt-0.5">-35%</h5>
                    </div>
                  </div>
                </div>

                {/* 2. Next Alarm & Active Streak (7 columns) */}
                <div className="md:col-span-7 flex flex-col gap-6">
                  {/* Active Streak Card */}
                  <div className="glass-card rounded-2xl p-5 border border-blue-500/20 relative overflow-hidden flex-1 flex flex-col justify-between shadow-lg">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-[#571bc1]/10 rounded-full blur-[40px] pointer-events-none"></div>
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <span className="text-xs font-bold text-[#adc6ff] uppercase tracking-wider flex items-center gap-1">
                          <Sparkles className="w-4 h-4 text-[#adc6ff] animate-spin" /> Wake-up Streak
                        </span>
                        <h4 className="text-3xl font-black text-white font-display mt-2">12 Days</h4>
                      </div>
                      <span className="text-[10px] font-mono font-bold bg-blue-500/10 text-[#adc6ff] border border-blue-500/20 px-2 py-0.5 rounded">
                        LEADERBOARD #4
                      </span>
                    </div>
                    <p className="text-xs text-[#c2c6d6] font-light leading-relaxed">
                      You are in the top 8% of morning activators. Completing tomorrow's Memory challenge unlocks the <span className="font-bold text-[#adc6ff]">Zen master badge</span>!
                    </p>
                  </div>

                  {/* Next Alarm Widget */}
                  <div className="glass-card rounded-2xl p-5 border border-[#424754]/20 flex-1 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-[#1c2026] border border-[#424754]/30 rounded-xl flex items-center justify-center text-[#adc6ff]">
                        <Clock className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold font-mono text-slate-400 uppercase tracking-widest block">Next Scheduled Alarm</span>
                        <h3 className="text-2xl font-bold font-mono text-white mt-0.5">
                          {nextAlarm ? `${nextAlarm.time}` : "None"}
                        </h3>
                        <span className="text-xs text-[#c2c6d6]">
                          {nextAlarm ? `${nextAlarm.days.join(", ")} (${nextAlarm.challengeType})` : "Configure an alarm to begin"}
                        </span>
                      </div>
                    </div>

                    {nextAlarm && (
                      <button
                        onClick={() => onSimulateAlarm(nextAlarm)}
                        className="p-3 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                        title="Force simulator trigger immediately"
                      >
                        <Activity className="w-4 h-4 animate-pulse" /> Simulate Ring
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Sleep Coaching Recommendation Row */}
              {coachRecs.filter(r => !r.applied).map((rec) => (
                <div key={rec.id} className="p-5 border border-dashed border-[#571bc1]/40 rounded-2xl bg-[#571bc1]/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden animate-fade-in">
                  <div className="flex gap-3 items-start">
                    <div className="w-10 h-10 rounded-xl bg-[#571bc1]/20 border border-purple-500/30 flex items-center justify-center text-purple-400 flex-shrink-0 mt-0.5">
                      <Brain className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#adc6ff] uppercase tracking-wider">{rec.coachName} recommendation</span>
                        <span className="text-[9px] bg-[#571bc1] text-white px-1.5 rounded uppercase font-mono font-bold tracking-wider">Clinical</span>
                      </div>
                      <p className="text-xs text-white leading-relaxed font-light mt-1 max-w-2xl">{rec.text}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleApplyRecommendation(rec.id)}
                    className="px-5 py-2 bg-purple-500/20 hover:bg-purple-500/30 text-[#d0bcff] border border-purple-500/30 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors"
                  >
                    Accept Sleep Tip
                  </button>
                </div>
              ))}

              {/* Bottom Row: AI Insights Engine */}
              <div className="glass-card rounded-3xl p-6 border border-[#424754]/20 flex flex-col gap-5 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-[#005ac2]/5 rounded-full blur-[100px] pointer-events-none"></div>
                
                <div className="flex justify-between items-center border-b border-[#424754]/20 pb-4">
                  <h3 className="text-xs font-bold text-[#adc6ff] uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#adc6ff]" /> CogniWake Insights Engine
                  </h3>
                  <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded font-mono font-bold">GEMINI 3.5 FLASH</span>
                </div>

                {loadingInsight ? (
                  <div className="py-6 flex items-center gap-3">
                    <div className="w-5 h-5 border-2 border-blue-500/20 border-t-blue-400 rounded-full animate-spin"></div>
                    <span className="text-xs text-[#c2c6d6] font-mono">Querying sleep model patterns...</span>
                  </div>
                ) : aiInsight ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <div>
                      <h4 className="font-bold text-white text-sm mb-1">Morning Wake Insight:</h4>
                      <p className="text-xs text-[#c2c6d6] leading-relaxed font-light">{aiInsight.insight}</p>
                    </div>
                    <div className="py-3.5 px-4 bg-[#10141a]/60 border border-[#424754]/10 rounded-xl flex gap-3 items-center">
                      <AlertCircle className="w-5 h-5 text-[#adc6ff] flex-shrink-0" />
                      <div>
                        <h5 className="font-bold text-[10px] uppercase font-mono text-slate-400 tracking-wider">Tonight's Action:</h5>
                        <p className="text-xs mt-0.5 text-[#dfe2eb] leading-normal">{aiInsight.tip}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">No custom sleep insights available.</p>
                )}
              </div>
            </div>
          )}

          {/* Sub Tab View Injectors */}
          {activeTab === 'alarms' && (
            <AlarmsTab
              alarms={alarms}
              onToggleAlarm={onToggleAlarm}
              onAddAlarm={onAddAlarm}
              onDeleteAlarm={onDeleteAlarm}
              onSimulateAlarm={onSimulateAlarm}
            />
          )}

          {activeTab === 'labs' && (
            <CognitiveLabsTab />
          )}

          {activeTab === 'performance' && (
            <PerformanceTab logs={logs} />
          )}

          {activeTab === 'settings' && (
            <SettingsTab
              user={user}
              onUpdateUser={(updated) => {
                onUpdateUser(updated);
              }}
            />
          )}

        </main>
      </div>
    </div>
  );
}
