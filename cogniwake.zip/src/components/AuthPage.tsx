import React, { useState, FormEvent } from "react";
import { Brain, Cpu, Lock, Shield, Eye, EyeOff, Check, UserPlus, LogIn } from "lucide-react";
import { User } from "../types";

interface AuthPageProps {
  onAuthSuccess: (user: User) => void;
  onBackToHome: () => void;
}

export default function AuthPage({ onAuthSuccess, onBackToHome }: AuthPageProps) {
  const [isSignUp, setIsSignUp] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<'user' | 'coach'>("user");
  const [showPassword, setShowPassword] = useState(false);
  const [previewSolved, setPreviewSolved] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (isSignUp && !name)) {
      setError("Please fill out all required fields.");
      return;
    }
    setError("");
    setLoading(true);

    try {
      const endpoint = isSignUp ? "/api/auth/register" : "/api/auth/login";
      const payload = isSignUp 
        ? { name, email, role, difficulty: "medium" } 
        : { email, password };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (data.success && data.user) {
        onAuthSuccess(data.user);
      } else {
        setError(data.error || "Authentication failed. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setError("Server connection failed. Proceeding with instant mock login...");
      // Instant graceful fallback login
      const fallbackUser: User = {
        id: `user-${Date.now()}`,
        name: name || email.split("@")[0] || "Guest User",
        email: email,
        role: role,
        difficulty: "medium",
        snoozeLimit: 3,
        avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"
      };
      setTimeout(() => onAuthSuccess(fallbackUser), 800);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0A0E14] text-[#dfe2eb] min-h-screen flex items-center justify-center font-sans overflow-hidden p-4 relative select-none">
      {/* Dynamic background lights */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#005ac2]/10 blur-[150px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#571bc1]/10 blur-[150px] rounded-full pointer-events-none"></div>

      <div className="w-full max-w-6xl bg-[#10141a] rounded-[2rem] border border-[#424754]/20 overflow-hidden flex flex-col lg:flex-row shadow-2xl relative z-10">
        
        {/* Left Side: Branded Panel (Desktop Only) */}
        <div className="hidden lg:flex w-1/2 bg-gradient-to-br from-[#0a0e14] to-[#1e1b4b] p-12 flex-col justify-between relative overflow-hidden">
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(circle_at_30%_30%,_#adc6ff_0%,_transparent_60%)]"></div>
          
          <div className="relative z-10">
            <div 
              className="flex items-center gap-3 mb-12 cursor-pointer hover:opacity-90 transition-opacity"
              onClick={onBackToHome}
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
                <Brain className="w-5 h-5 text-[#adc6ff]" />
              </div>
              <h1 className="font-display text-xl font-extrabold text-[#dfe2eb] tracking-tight">CogniWake</h1>
            </div>

            <h2 className="font-display text-5xl font-extrabold text-white leading-tight mb-4">
              Wake Up <br />
              <span className="energy-gradient-text">Your Mind.</span>
            </h2>
            <p className="text-md text-[#c2c6d6] font-light max-w-sm leading-relaxed">
              Peak performance starts with morning clarity. Transition smoothly from deep rest to focused analytical energy.
            </p>
          </div>

          {/* Illustrative Challenge Card */}
          <div className="relative z-10 bg-[#161b22]/80 backdrop-blur-md rounded-2xl p-6 border border-white/10 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-[#adc6ff] uppercase tracking-wider font-mono">Daily Challenge Practice</span>
              <Cpu className="w-4 h-4 text-[#c2c6d6]" />
            </div>
            
            <div className="bg-[#10141a] rounded-xl p-6 border border-[#424754]/30 text-center relative overflow-hidden">
              <span className="text-lg font-bold font-mono tracking-wide text-white block">
                Complete Sequence: <br />
                2, 4, 8, <span className="text-[#adc6ff] underline underline-offset-4">__</span>
              </span>
              {previewSolved === 16 && (
                <div className="mt-2 text-xs font-mono text-emerald-400 font-bold flex items-center justify-center gap-1.5 animate-bounce">
                  <Check className="w-4 h-4" /> Correct! Prefrontal lobe initialized!
                </div>
              )}
            </div>

            <div className="mt-4 flex gap-3">
              {[10, 12, 16].map((num) => (
                <button
                  key={num}
                  onClick={() => setPreviewSolved(num)}
                  className={`flex-1 h-11 rounded-xl font-mono text-sm font-bold border transition-all cursor-pointer ${
                    previewSolved === num
                      ? num === 16
                        ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                        : "bg-red-500/10 border-red-500/50 text-red-400"
                      : "bg-[#10141a] border-[#424754]/30 text-[#c2c6d6] hover:bg-[#1c2026] hover:border-[#adc6ff]/40"
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Form Area */}
        <div className="w-full lg:w-1/2 bg-[#10141a] flex flex-col justify-center p-8 md:p-12 relative">
          <div className="max-w-md w-full mx-auto">
            
            {/* Mobile Header */}
            <div 
              className="lg:hidden flex items-center gap-3 mb-8 justify-center cursor-pointer"
              onClick={onBackToHome}
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
                <Brain className="w-5 h-5 text-[#adc6ff]" />
              </div>
              <h1 className="font-display text-xl font-extrabold text-[#dfe2eb] tracking-tight">CogniWake</h1>
            </div>

            <div className="text-center mb-8">
              <h2 className="font-display text-3xl font-black text-white mb-2">
                {isSignUp ? "Create an Account" : "Welcome Back"}
              </h2>
              <p className="text-sm text-[#c2c6d6]">
                {isSignUp ? "Enter your details to build a better routine." : "Enter your credentials to access your dashboard."}
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <div>
                  <label className="block text-xs font-semibold text-[#c2c6d6] uppercase tracking-wider mb-1.5" htmlFor="name">Full Name</label>
                  <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3 text-[#dfe2eb] focus:border-[#adc6ff] focus:ring-1 focus:ring-[#adc6ff] focus:outline-none transition-colors text-sm"
                    required={isSignUp}
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#c2c6d6] uppercase tracking-wider mb-1.5" htmlFor="email">Email Address</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex@cogniwake.com"
                  className="w-full bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3 text-[#dfe2eb] focus:border-[#adc6ff] focus:ring-1 focus:ring-[#adc6ff] focus:outline-none transition-colors text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#c2c6d6] uppercase tracking-wider mb-1.5" htmlFor="password">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#1c2026] border border-[#424754]/50 rounded-xl pl-4 pr-11 py-3 text-[#dfe2eb] focus:border-[#adc6ff] focus:ring-1 focus:ring-[#adc6ff] focus:outline-none transition-colors text-sm font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-[#c2c6d6] hover:text-[#dfe2eb] cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {isSignUp && (
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-[#c2c6d6] uppercase tracking-wider mb-2">I am signing up as a...</label>
                  <div className="flex gap-4">
                    <label className="flex-1 cursor-pointer">
                      <input
                        type="radio"
                        name="role"
                        value="user"
                        checked={role === "user"}
                        onChange={() => setRole("user")}
                        className="peer sr-only"
                      />
                      <div className="w-full text-center py-3 rounded-xl border border-[#424754]/50 peer-checked:border-[#adc6ff] peer-checked:bg-[#005ac2]/10 peer-checked:text-[#adc6ff] transition-all font-semibold text-sm text-[#c2c6d6]">
                        Standard User
                      </div>
                    </label>
                    <label className="flex-1 cursor-pointer">
                      <input
                        type="radio"
                        name="role"
                        value="coach"
                        checked={role === "coach"}
                        onChange={() => setRole("coach")}
                        className="peer sr-only"
                      />
                      <div className="w-full text-center py-3 rounded-xl border border-[#424754]/50 peer-checked:border-[#adc6ff] peer-checked:bg-[#005ac2]/10 peer-checked:text-[#adc6ff] transition-all font-semibold text-sm text-[#c2c6d6]">
                        Wellness Coach
                      </div>
                    </label>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full energy-gradient-bg text-white rounded-xl py-3.5 mt-6 font-bold text-sm hover:opacity-90 transition-all shadow-lg shadow-[#005ac2]/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                ) : isSignUp ? (
                  <>
                    <UserPlus className="w-4 h-4" /> Sign Up
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" /> Log In
                  </>
                )}
              </button>
            </form>

            {/* Google OAuth2 Button */}
            <button
              type="button"
              onClick={async () => {
                setLoading(true);
                try {
                  const res = await fetch("/api/auth/oauth-simulate", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      email: isSignUp ? email || "google-user@gmail.com" : "alex@cogniwake.com",
                      name: isSignUp ? name || "Google Account" : "Alex Rivera",
                      role: role
                    })
                  });
                  const data = await res.json();
                  if (data.success && data.user) {
                    onAuthSuccess(data.user);
                  } else {
                    setError("Google OAuth2 simulation failed.");
                  }
                } catch (err) {
                  setError("Google OAuth2 connection error.");
                } finally {
                  setLoading(false);
                }
              }}
              className="w-full mt-4 bg-white hover:bg-slate-100 text-slate-900 border border-slate-300 font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-3 transition-colors text-sm cursor-pointer"
            >
              <svg className="w-4.5 h-4.5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              <span>Continue with Google (OAuth2)</span>
            </button>

            {/* Social Divider */}
            <div className="mt-8 relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#424754]/30"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="px-3 bg-[#10141a] text-[#c2c6d6] font-semibold uppercase tracking-wider font-mono">Demo Quick Login</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4">
              <button
                onClick={() => {
                  setEmail("alex@cogniwake.com");
                  setPassword("password");
                  setIsSignUp(false);
                }}
                className="flex items-center justify-center gap-2 bg-[#1c2026] border border-[#424754]/30 rounded-xl py-3 hover:bg-[#353940]/50 transition-colors cursor-pointer text-xs font-semibold text-white"
              >
                <LogIn className="w-4 h-4 text-[#adc6ff]" />
                User Account
              </button>
              <button
                onClick={() => {
                  setEmail("sarah@cogniwake.com");
                  setPassword("password");
                  setIsSignUp(false);
                }}
                className="flex items-center justify-center gap-2 bg-[#1c2026] border border-[#424754]/30 rounded-xl py-3 hover:bg-[#353940]/50 transition-colors cursor-pointer text-xs font-semibold text-white"
              >
                <LogIn className="w-4 h-4 text-[#d0bcff]" />
                Coach Account
              </button>
            </div>

            <div className="mt-8 text-center">
              <p className="text-sm text-[#c2c6d6]">
                {isSignUp ? "Already have an account? " : "Don't have an account? "}
                <button
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setError("");
                  }}
                  className="text-[#adc6ff] hover:underline font-bold cursor-pointer bg-transparent border-none outline-none ml-1"
                >
                  {isSignUp ? "Log In" : "Sign Up"}
                </button>
              </p>
            </div>

            {/* Trust Indicators */}
            <div className="mt-12 flex justify-center gap-8 pt-6 border-t border-[#424754]/10 text-[#c2c6d6]/60">
              <div className="flex items-center gap-2 text-xs">
                <Lock className="w-4 h-4 text-[#adc6ff]/50" />
                <span>Secure JWT Auth</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <Shield className="w-4 h-4 text-[#adc6ff]/50" />
                <span>Privacy First</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
