import { motion } from "motion/react";
import { Brain, Clock, Zap, Target, Sparkles, TrendingUp, ChevronRight, Activity, ArrowRight } from "lucide-react";

interface LandingPageProps {
  onGetStarted: () => void;
  onLoginClick: () => void;
}

export default function LandingPage({ onGetStarted, onLoginClick }: LandingPageProps) {
  return (
    <div className="bg-[#0A0E14] text-[#dfe2eb] min-h-screen font-sans overflow-x-hidden select-none">
      {/* Top Navigation Bar */}
      <nav className="bg-[#10141a]/80 backdrop-blur-lg border-b border-[#424754]/20 fixed top-0 w-full z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center shadow-lg shadow-blue-500/10">
              <Brain className="w-6 h-6 text-[#adc6ff]" />
            </div>
            <span className="font-display text-2xl font-extrabold text-[#dfe2eb] tracking-tight">CogniWake</span>
          </div>
          
          <div className="hidden md:flex gap-8 items-center">
            <a className="text-[#adc6ff] font-bold border-b-2 border-[#adc6ff] pb-1 text-sm font-display" href="#features">Features</a>
            <a className="text-[#c2c6d6] hover:text-[#dfe2eb] transition-colors text-sm hover:bg-[#353940]/50 px-3 py-1.5 rounded-lg duration-300 font-display" href="#how-it-works">How It Works</a>
            <a className="text-[#c2c6d6] hover:text-[#dfe2eb] transition-colors text-sm hover:bg-[#353940]/50 px-3 py-1.5 rounded-lg duration-300 font-display" href="#science">Scientific Basis</a>
            <a className="text-[#c2c6d6] hover:text-[#dfe2eb] transition-colors text-sm hover:bg-[#353940]/50 px-3 py-1.5 rounded-lg duration-300 font-display" href="#pricing">Pricing</a>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={onLoginClick}
              className="text-[#c2c6d6] hover:text-[#dfe2eb] font-semibold text-sm transition-colors cursor-pointer"
            >
              Log In
            </button>
            <button 
              onClick={onGetStarted}
              className="energy-gradient-bg text-white font-semibold text-sm px-6 py-2.5 rounded-full hover:shadow-[0_0_15px_rgba(173,198,255,0.4)] transition-all transform hover:scale-95 cursor-pointer flex items-center gap-2"
            >
              Get Started
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="pt-32 pb-16 px-6 md:px-12 max-w-7xl mx-auto flex flex-col gap-16">
        <section className="flex flex-col lg:flex-row items-center gap-12 min-h-[600px] mt-8">
          <div className="flex-1 flex flex-col gap-6 lg:pr-8 text-center lg:text-left">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#1c2026] border border-[#424754]/30 w-fit mx-auto lg:mx-0"
            >
              <Sparkles className="w-4 h-4 text-[#adc6ff]" />
              <span className="text-xs font-semibold text-[#adc6ff] tracking-wide uppercase">Next-Gen Sleep Inertia Blaster</span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold text-[#dfe2eb] leading-tight"
            >
              End the Snooze Cycle with <br />
              <span className="energy-gradient-text">AI-Powered Challenges.</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-[#c2c6d6] max-w-2xl mx-auto lg:mx-0 font-light leading-relaxed"
            >
              Build consistent wake-up habits by solving adaptive puzzles, memory challenges, and quick math before your alarm can be dismissed. Reset your brain's morning clarity instantly.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 pt-4 justify-center lg:justify-start"
            >
              <button 
                onClick={onGetStarted}
                className="energy-gradient-bg text-white font-bold text-md px-8 py-4 rounded-full hover:shadow-[0_0_20px_rgba(173,198,255,0.5)] transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                Get Started Free
                <ArrowRight className="w-5 h-5" />
              </button>
              <a 
                href="#how-it-works"
                className="bg-white/10 border border-white/20 text-[#dfe2eb] font-bold text-md px-8 py-4 rounded-full hover:bg-white/20 transition-all cursor-pointer flex items-center justify-center"
              >
                See How It Works
              </a>
            </motion.div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex-1 relative w-full flex justify-center lg:justify-end"
          >
            {/* Decorative background elements */}
            <div className="absolute inset-0 bg-[#adc6ff]/10 blur-[100px] rounded-full pointer-events-none w-3/4 h-3/4 m-auto"></div>
            <div className="relative w-full max-w-sm glass-card rounded-[2.5rem] p-4 ambient-glow">
              <div className="bg-[#0a0e14] rounded-[2rem] overflow-hidden border border-[#424754]/50 relative group">
                <img 
                  className="w-full h-auto object-cover block filter brightness-90 group-hover:brightness-100 transition-all duration-500" 
                  alt="CogniWake App Matrix Screen"
                  src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=600"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e14] via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#10141a]/90 backdrop-blur-md rounded-xl border border-white/10">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-[#adc6ff] uppercase tracking-widest font-mono">Memory Matrix</span>
                    <Clock className="w-4 h-4 text-[#adc6ff]" />
                  </div>
                  <h4 className="text-sm font-semibold mb-1">Verify sequence of 5 tiles</h4>
                  <div className="flex gap-1.5 mt-2">
                    <div className="w-6 h-6 rounded bg-blue-500/20 border border-blue-500"></div>
                    <div className="w-6 h-6 rounded bg-purple-500/20 border border-purple-500"></div>
                    <div className="w-6 h-6 rounded bg-[#ffb690]/20 border border-[#ffb690]"></div>
                    <div className="w-6 h-6 rounded bg-slate-800"></div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Stats Band */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 py-10 border-y border-[#424754]/20">
          <div className="flex flex-col items-center text-center">
            <span className="font-display text-5xl md:text-6xl font-black text-[#adc6ff] tracking-tight">35%</span>
            <span className="font-display text-xs text-[#c2c6d6] uppercase tracking-widest mt-2 font-bold">fewer snoozes logged</span>
          </div>
          <div className="flex flex-col items-center text-center">
            <span className="font-display text-5xl md:text-6xl font-black text-[#d0bcff] tracking-tight">92%</span>
            <span className="font-display text-xs text-[#c2c6d6] uppercase tracking-widest mt-2 font-bold">Habit Score improvement</span>
          </div>
        </section>

        {/* Features Grid Section */}
        <section id="features" className="py-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-extrabold mb-4">Waking Up Has Never Been This Smart</h2>
            <p className="text-[#c2c6d6] max-w-2xl mx-auto">Standard alarms trigger stress and grogginess. CogniWake stimulates blood flow to prefrontal cortex using evidence-based cognitive mechanics.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Brain className="w-6 h-6 text-[#adc6ff]" />,
                title: "Prefrontal Stimulation",
                desc: "Math equations ranging from double addition to medium algebra, structured to trigger analytical neural circuits."
              },
              {
                icon: <Clock className="w-6 h-6 text-[#d0bcff]" />,
                title: "Spatial Memory Matrix",
                desc: "Grid-based memory triggers that wake up visual-spatial tracking channels, reducing cognitive drag."
              },
              {
                icon: <Zap className="w-6 h-6 text-[#ffb690]" />,
                title: "Progressive Sequences",
                desc: "Arithmetic and logical number patterns that strengthen memory recall and morning focus."
              },
              {
                icon: <Target className="w-6 h-6 text-emerald-400" />,
                title: "Sleep-Wake Coach Hub",
                desc: "Join as a User or Wellness Coach to monitor sleep plans, analyze metrics, and share feedback."
              }
            ].map((f, i) => (
              <div key={i} className="bg-[#161b22]/50 border border-[#424754]/20 rounded-2xl p-6 hover:border-[#adc6ff]/40 transition-all group">
                <div className="w-12 h-12 rounded-xl bg-[#10141a] flex items-center justify-center border border-[#424754]/30 mb-4 group-hover:scale-105 transition-all">
                  {f.icon}
                </div>
                <h3 className="font-display text-lg font-bold mb-2 group-hover:text-[#adc6ff] transition-colors">{f.title}</h3>
                <p className="text-sm text-[#c2c6d6] leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* How it Works / Process */}
        <section id="how-it-works" className="py-8">
          <div className="glass-card rounded-3xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-[#571bc1]/10 rounded-full blur-[100px] pointer-events-none"></div>
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-display font-black mb-6">Unlocking Cognitive Readiness in 3 Steps</h2>
                <div className="space-y-8">
                  {[
                    { step: "01", title: "Set Your Dynamic Alarm", text: "Choose your preferred time, recurring days, and puzzle difficulty (Easy, Medium, Hard)." },
                    { step: "02", title: "Wake Up & Solve to Dismiss", "text": "When the alarm rings, a gorgeous full-screen visual puzzle generates. Solve it to turn off the audio." },
                    { step: "03", title: "Analyze Performance Trends", "text": "Track your accuracy, completion speed, and streak points to optimize your morning routine." }
                  ].map((s, idx) => (
                    <div key={idx} className="flex gap-4 items-start">
                      <span className="font-mono text-xl font-bold text-[#adc6ff] bg-blue-500/10 px-3 py-1 rounded-lg border border-blue-500/20">{s.step}</span>
                      <div>
                        <h4 className="font-display text-lg font-bold mb-1 text-[#dfe2eb]">{s.title}</h4>
                        <p className="text-sm text-[#c2c6d6]">{s.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-center">
                <div className="relative w-full max-w-md bg-[#10141a] border border-[#424754]/40 rounded-2xl p-6 shadow-2xl">
                  <div className="flex justify-between items-center pb-4 border-b border-[#424754]/20 mb-4">
                    <span className="text-[#adc6ff] text-xs font-mono font-bold uppercase tracking-widest flex items-center gap-2">
                      <Activity className="w-4 h-4" /> Live AI Engine
                    </span>
                    <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-mono">ACTIVE</span>
                  </div>
                  <div className="p-4 bg-[#161b22] border border-[#424754]/20 rounded-xl mb-4">
                    <p className="text-xs font-mono text-[#c2c6d6]">PROMPT INJECTED TO GEMINI API:</p>
                    <p className="text-sm font-sans mt-2 text-[#dfe2eb]">"Generate math puzzle difficulty: HARD for User Alex Rivera who has a streak of 12 days..."</p>
                  </div>
                  <div className="p-4 bg-gradient-to-r from-[#005ac2]/10 to-[#571bc1]/10 rounded-xl border border-blue-500/20">
                    <p className="text-xs font-mono text-[#adc6ff]">GENERATED CHALLENGE:</p>
                    <p className="text-md font-bold mt-2 text-white">Solve: (14 * 7) - 23</p>
                    <div className="grid grid-cols-2 gap-2 mt-3">
                      {["75", "98", "65", "83"].map((val, i) => (
                        <div key={i} className={`p-2 rounded border text-center text-xs font-semibold ${val === "75" ? "border-blue-500/50 bg-blue-500/10 text-[#adc6ff]" : "border-[#424754]/30 bg-[#10141a]"}`}>{val}</div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Science Basis Section */}
        <section id="science" className="py-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-extrabold mb-4">The Science Behind Grogginess</h2>
            <p className="text-[#c2c6d6] max-w-2xl mx-auto">Why standard alarms make you feel tired, and how active engagement cures sleep inertia.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-[#10141a] border border-[#424754]/20 rounded-2xl p-8 flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono text-[#ffb690] bg-[#ffb690]/10 border border-[#ffb690]/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">The Problem</span>
                <h3 className="text-xl font-display font-bold mt-4 mb-3">Sleep Inertia</h3>
                <p className="text-sm text-[#c2c6d6] leading-relaxed">Waking up in the middle of a deep sleep stage floods your brain with adenosine. This causes up to 4 hours of grogginess, slow reflexes, and weak memory.</p>
              </div>
              <div className="border-t border-[#424754]/20 pt-4 mt-6">
                <span className="text-xs text-[#c2c6d6] italic">Result: 3-4 consecutive alarm snoozes.</span>
              </div>
            </div>

            <div className="bg-[#10141a] border border-[#424754]/20 rounded-2xl p-8 flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono text-[#adc6ff] bg-[#005ac2]/10 border border-blue-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">The Trigger</span>
                <h3 className="text-xl font-display font-bold mt-4 mb-3">Snooze Compounding</h3>
                <p className="text-sm text-[#c2c6d6] leading-relaxed">Pressing snooze tricks your brain into restarting a new sleep cycle. When the alarm rings 9 minutes later, you are dragged out of an even deeper stage, compounding fatigue.</p>
              </div>
              <div className="border-t border-[#424754]/20 pt-4 mt-6">
                <span className="text-xs text-[#c2c6d6] italic">Result: Elevated morning stress hormone (cortisol).</span>
              </div>
            </div>

            <div className="bg-[#10141a] border border-[#424754]/20 rounded-2xl p-8 flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">The Cure</span>
                <h3 className="text-xl font-display font-bold mt-4 mb-3">Cognitive Activation</h3>
                <p className="text-sm text-[#c2c6d6] leading-relaxed">Solving structured math and sequence puzzles activates your prefrontal cortex. This triggers dopamine release and suppresses sleep chemicals naturally within 60 seconds.</p>
              </div>
              <div className="border-t border-[#424754]/20 pt-4 mt-6">
                <span className="text-xs text-[#c2c6d6] italic">Result: 92% of users report feeling alert in 2 minutes.</span>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-extrabold mb-4">Choose Your Path to Alertness</h2>
            <p className="text-[#c2c6d6] max-w-2xl mx-auto">Simple, transparent options for users and health professionals alike.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-[#10141a] border border-[#424754]/20 rounded-2xl p-8 flex flex-col justify-between hover:border-[#adc6ff]/30 transition-all">
              <div>
                <h4 className="text-lg font-display font-bold text-white mb-1">Standard Wake Tier</h4>
                <p className="text-sm text-[#c2c6d6] mb-6">Perfect for individuals wanting a better morning routine.</p>
                <div className="flex items-baseline gap-2 mb-6">
                  <span className="text-4xl font-display font-extrabold text-white">$0</span>
                  <span className="text-sm text-[#c2c6d6]">Free Forever</span>
                </div>
                <ul className="space-y-3 text-sm text-[#c2c6d6]">
                  <li className="flex items-center gap-2">✔ Create up to 5 alarms</li>
                  <li className="flex items-center gap-2">✔ Access local practice labs</li>
                  <li className="flex items-center gap-2">✔ standard math and memory puzzles</li>
                  <li className="flex items-center gap-2">✔ 7-day performance tracking</li>
                </ul>
              </div>
              <button 
                onClick={onGetStarted}
                className="w-full bg-[#1c2026] text-[#dfe2eb] hover:bg-[#353940] transition-colors py-3.5 rounded-xl font-semibold text-sm mt-8 cursor-pointer"
              >
                Sign Up Now
              </button>
            </div>

            <div className="bg-[#161b22] border-2 border-[#571bc1]/50 rounded-2xl p-8 flex flex-col justify-between relative overflow-hidden shadow-xl shadow-purple-500/5">
              <div className="absolute top-4 right-4 bg-[#571bc1] text-white text-xs font-bold font-mono px-3 py-1 rounded-full">POPULAR</div>
              <div>
                <h4 className="text-lg font-display font-bold text-[#adc6ff] mb-1">AI-Powered Premium + Coach</h4>
                <p className="text-sm text-[#c2c6d6] mb-6">For power users and professional wellness coaches.</p>
                <div className="flex items-baseline gap-2 mb-6">
                  <span className="text-4xl font-display font-extrabold text-white">$9</span>
                  <span className="text-sm text-[#c2c6d6]">/ month</span>
                </div>
                <ul className="space-y-3 text-sm text-[#c2c6d6]">
                  <li className="flex items-center gap-2 text-white">✔ Unlimited Alarms</li>
                  <li className="flex items-center gap-2 text-white">✔ Advanced Gemini AI Puzzle Generation</li>
                  <li className="flex items-center gap-2 text-white">✔ Personalized Wake-Up Sleep Coaching</li>
                  <li className="flex items-center gap-2 text-white">✔ Premium audio chime collection</li>
                  <li className="flex items-center gap-2 text-white">✔ Shared dashboard connection</li>
                </ul>
              </div>
              <button 
                onClick={onGetStarted}
                className="w-full energy-gradient-bg text-white hover:opacity-95 transition-opacity py-3.5 rounded-xl font-bold text-sm mt-8 cursor-pointer shadow-lg shadow-purple-500/20"
              >
                Try Premium For Free
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#0a0e14] border-t border-[#424754]/10 w-full py-12 px-6 mt-16 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
              <Brain className="w-5 h-5 text-[#adc6ff]" />
            </div>
            <span className="font-display text-xl font-extrabold text-[#dfe2eb]">CogniWake</span>
          </div>
          <div className="text-[#c2c6d6] text-xs text-center md:text-left">
            © 2026 CogniWake. Peak Performance Starts Here.
          </div>
          <div className="flex gap-6 text-xs text-[#c2c6d6]">
            <a className="hover:text-[#adc6ff] transition-colors" href="#">Privacy Policy</a>
            <a className="hover:text-[#adc6ff] transition-colors" href="#">Terms of Service</a>
            <a className="hover:text-[#adc6ff] transition-colors" href="#">Research Papers</a>
            <a className="hover:text-[#adc6ff] transition-colors" href="#">Contact Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
