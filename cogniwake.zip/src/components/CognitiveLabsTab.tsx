import { useState } from "react";
import { Brain, Sparkles, Cpu, Sliders, CheckCircle, AlertTriangle, ArrowRight } from "lucide-react";
import { Puzzle } from "../types";

export default function CognitiveLabsTab() {
  const [category, setCategory] = useState<'math' | 'memory' | 'sequence' | 'word'>("math");
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>("medium");
  const [puzzle, setPuzzle] = useState<Puzzle | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [solvedLogs, setSolvedLogs] = useState<{ id: string; type: string; success: boolean; date: string }[]>([]);

  const generatePuzzle = async () => {
    setLoading(true);
    setSelectedAnswer(null);
    setIsSubmitted(false);
    setPuzzle(null);

    try {
      const response = await fetch("/api/challenges/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: category, difficulty }),
      });
      const data = await response.json();
      setPuzzle(data);
    } catch (err) {
      console.error(err);
      // fallback
      setPuzzle({
        id: `practice-${Date.now()}`,
        type: category,
        question: `Unscramble this sleep-related word: 'K E U P A W'`,
        options: ["WAKEUP", "PACKED", "WEEKLY", "KEEPER"],
        correctAnswer: "WAKEUP",
        hint: "It's the goal of CogniWake!",
        explanation: "W-A-K-E-U-P scrambles to K E U P A W."
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOptionSelect = (opt: string) => {
    if (isSubmitted) return;
    setSelectedAnswer(opt);
  };

  const handleVerify = () => {
    if (!puzzle || !selectedAnswer) return;
    setIsSubmitted(true);
    const isCorrect = selectedAnswer === puzzle.correctAnswer;
    
    // Log practice history
    setSolvedLogs(prev => [
      {
        id: puzzle.id,
        type: puzzle.type,
        success: isCorrect,
        date: new Date().toLocaleTimeString(),
      },
      ...prev
    ]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      
      {/* Parameters Panel */}
      <section className="lg:col-span-4 flex flex-col gap-6">
        <div className="glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col gap-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#adc6ff]" /> LAB PARAMETERS
            </h3>
            <p className="text-xs text-[#c2c6d6] mt-1">Configure parameters to generate dynamic tasks.</p>
          </div>

          {/* Category */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Cognitive Dimension</label>
            <div className="flex flex-col gap-1.5">
              {[
                { type: "math" as const, name: "🧮 Math & Algebra", desc: "Arithmetical problem-solving" },
                { type: "memory" as const, name: "🧩 Spatial Memory Grid", desc: "Short term recall sequences" },
                { type: "sequence" as const, name: "🔢 Logical Sequence Patterns", desc: "Predictive pattern analysis" },
                { type: "word" as const, name: "🔤 Word & Anagram Labs", desc: "Semantic structural parsing" },
              ].map((c) => (
                <button
                  key={c.type}
                  onClick={() => setCategory(c.type)}
                  className={`w-full py-3.5 px-4 rounded-xl border text-left transition-all cursor-pointer ${
                    category === c.type
                      ? "bg-[#005ac2]/10 border-[#adc6ff] text-[#adc6ff] shadow-inner"
                      : "bg-[#1c2026]/40 border-[#424754]/30 text-[#c2c6d6] hover:bg-[#353940]/20 hover:border-[#adc6ff]/20"
                  }`}
                >
                  <span className="block text-xs font-bold">{c.name}</span>
                  <span className="block text-[10px] text-slate-400 font-light mt-0.5">{c.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Intensity Level</label>
            <div className="flex gap-2">
              {(["easy", "medium", "hard"] as const).map((diff) => (
                <button
                  key={diff}
                  onClick={() => setDifficulty(diff)}
                  className={`flex-1 py-3 px-3 rounded-xl border text-xs font-bold uppercase transition-all cursor-pointer ${
                    difficulty === diff
                      ? "bg-[#005ac2]/20 border-[#adc6ff] text-[#adc6ff] shadow-inner"
                      : "bg-[#1c2026]/40 border-[#424754]/40 text-[#c2c6d6] hover:bg-[#353940]/30"
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generatePuzzle}
            disabled={loading}
            className="w-full energy-gradient-bg hover:opacity-95 text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-lg shadow-blue-500/10 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Brain className="w-4 h-4 animate-pulse" /> {loading ? "Generating..." : "Generate AI Task"}
          </button>
        </div>
      </section>

      {/* Active Puzzle Canvas */}
      <section className="lg:col-span-8 flex flex-col gap-6">
        <div className="glass-card rounded-2xl p-6 md:p-8 border border-[#424754]/20 flex flex-col min-h-[450px] justify-center relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#adc6ff]/5 rounded-full blur-[80px] pointer-events-none"></div>

          {loading ? (
            <div className="flex flex-col items-center justify-center gap-4 py-20">
              <div className="w-10 h-10 border-4 border-blue-500/20 border-t-blue-400 rounded-full animate-spin"></div>
              <p className="text-xs font-mono text-[#adc6ff] uppercase tracking-widest font-bold flex items-center gap-1.5">
                <Cpu className="w-4 h-4 animate-spin" /> Querying Gemini AI model...
              </p>
            </div>
          ) : puzzle ? (
            <div className="flex flex-col gap-6">
              <header className="flex justify-between items-center pb-4 border-b border-[#424754]/20">
                <span className="text-xs font-bold font-mono text-[#adc6ff] uppercase bg-[#adc6ff]/10 px-2.5 py-1 rounded-md border border-blue-500/10 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 animate-spin" /> {puzzle.type} dimension
                </span>
                <span className="text-xs font-bold font-mono text-[#ffb690] uppercase bg-[#ffb690]/10 px-2.5 py-1 rounded-md border border-orange-500/20">
                  {difficulty}
                </span>
              </header>

              <p className="text-lg md:text-xl font-bold text-white leading-relaxed font-sans mt-2">
                {puzzle.question}
              </p>

              {/* Multiple Choice Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                {puzzle.options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleOptionSelect(option)}
                    className={`w-full py-4 px-6 rounded-xl font-sans text-sm font-bold text-left border transition-all cursor-pointer flex justify-between items-center ${
                      selectedAnswer === option
                        ? isSubmitted
                          ? option === puzzle.correctAnswer
                            ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                            : "bg-red-500/20 border-red-500 text-red-400"
                          : "bg-[#005ac2]/20 border-[#adc6ff] text-[#adc6ff]"
                        : isSubmitted && option === puzzle.correctAnswer
                        ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                        : "bg-[#1c2026]/40 border-[#424754]/50 text-[#dfe2eb] hover:bg-[#353940]/50"
                    }`}
                  >
                    <span>{option}</span>
                    {isSubmitted && option === puzzle.correctAnswer && (
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                    )}
                  </button>
                ))}
              </div>

              {/* Action Trigger */}
              {!isSubmitted ? (
                <button
                  onClick={handleVerify}
                  disabled={!selectedAnswer}
                  className="w-full bg-[#1c2026] hover:bg-[#353940] text-[#dfe2eb] border border-[#424754]/50 py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
                >
                  Verify Calibration <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="mt-4 flex flex-col gap-4 animate-fade-in">
                  <div className={`p-4 rounded-xl border flex gap-3 ${
                    selectedAnswer === puzzle.correctAnswer
                      ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                      : "bg-red-500/10 border-red-500/20 text-red-300"
                  }`}>
                    {selectedAnswer === puzzle.correctAnswer ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <h4 className="font-bold text-sm">
                        {selectedAnswer === puzzle.correctAnswer ? "Task Complete!" : "Calibration Error"}
                      </h4>
                      <p className="text-xs mt-1 font-light opacity-90 leading-relaxed">{puzzle.explanation}</p>
                    </div>
                  </div>

                  <button
                    onClick={generatePuzzle}
                    className="w-full energy-gradient-bg text-white py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    Next Lab Challenge <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="py-12 text-center flex flex-col items-center justify-center gap-4">
              <Brain className="w-12 h-12 text-slate-500" />
              <div>
                <h4 className="font-display font-bold text-white text-md mb-1">Cognitive Labs Idle</h4>
                <p className="text-xs text-[#c2c6d6] max-w-sm">Select puzzle parameters on the left and click "Generate AI Task" to fetch real questions from Gemini model.</p>
              </div>
            </div>
          )}
        </div>

        {/* Local Practice Stats Logs */}
        {solvedLogs.length > 0 && (
          <div className="glass-card rounded-2xl p-5 border border-[#424754]/20">
            <h4 className="text-xs font-bold text-[#adc6ff] uppercase tracking-wider mb-3">Practice Calibration History</h4>
            <div className="flex flex-col gap-2 max-h-[140px] overflow-y-auto no-scrollbar">
              {solvedLogs.map((log, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs py-2 border-b border-[#424754]/10">
                  <span className="font-mono text-[#c2c6d6]">{log.date}</span>
                  <span className="font-mono text-slate-400 uppercase font-bold">{log.type} lab</span>
                  <span className={`font-mono font-extrabold ${log.success ? "text-emerald-400" : "text-red-400"}`}>
                    {log.success ? "PASSED" : "FAILED"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
