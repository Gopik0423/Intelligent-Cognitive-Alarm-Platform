import React, { useState, useEffect, FormEvent } from "react";
import { User, Users, FileSpreadsheet, PlusCircle, Sparkles, Send, CheckCircle } from "lucide-react";
import { ClientData, CoachRecommendation } from "../types";

interface CoachDashboardProps {
  onLogout: () => void;
}

export default function CoachDashboard({ onLogout }: CoachDashboardProps) {
  const [clients, setClients] = useState<ClientData[]>([]);
  const [recommendations, setRecommendations] = useState<CoachRecommendation[]>([]);
  const [newRecommendation, setNewRecommendation] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'clients' | 'broadcast'>('clients');

  // Load clients and past recommendations on mount
  useEffect(() => {
    const loadCoachData = async () => {
      try {
        const clientRes = await fetch("/api/coach/clients");
        const clientData = await clientRes.json();
        setClients(clientData);

        const recRes = await fetch("/api/coach/recommendations");
        const recData = await recRes.json();
        setRecommendations(recData);
      } catch (err) {
        console.error("Failed to load coach data:", err);
      }
    };
    loadCoachData();
  }, []);

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRecommendation.trim()) return;
    setSubmitting(true);
    setSuccess(false);

    try {
      const response = await fetch("/api/coach/recommendations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: newRecommendation })
      });
      const data = await response.json();
      setRecommendations(prev => [data, ...prev]);
      setNewRecommendation("");
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error("Failed to post recommendation:", err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#0A0E14] text-[#dfe2eb] min-h-screen font-sans flex">
      {/* Sidebar for Coach Dashboard */}
      <aside className="w-64 bg-[#10141a] border-r border-[#424754]/20 hidden md:flex flex-col justify-between p-6">
        <div className="flex flex-col gap-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#005ac2] to-[#571bc1] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#adc6ff]" />
            </div>
            <span className="font-display text-lg font-black text-white">Coach Hub</span>
          </div>

          <nav className="flex flex-col gap-2">
            <button
              onClick={() => setActiveTab('clients')}
              className={`w-full py-3 px-4 rounded-xl font-bold text-sm text-left transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'clients'
                  ? "bg-gradient-to-r from-[#005ac2] to-[#571bc1] text-white shadow-lg"
                  : "text-[#c2c6d6] hover:bg-[#1c2026] hover:text-white"
              }`}
            >
              <Users className="w-4 h-4" /> Client Database
            </button>
            <button
              onClick={() => setActiveTab('broadcast')}
              className={`w-full py-3 px-4 rounded-xl font-bold text-sm text-left transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'broadcast'
                  ? "bg-gradient-to-r from-[#005ac2] to-[#571bc1] text-white shadow-lg"
                  : "text-[#c2c6d6] hover:bg-[#1c2026] hover:text-white"
              }`}
            >
              <PlusCircle className="w-4 h-4" /> Broadcast Sleep Plan
            </button>
          </nav>
        </div>

        <button
          onClick={onLogout}
          className="w-full bg-[#1c2026] hover:bg-[#353940] py-3 rounded-xl font-semibold text-xs border border-slate-700/50 cursor-pointer"
        >
          Coach Sign Out
        </button>
      </aside>

      {/* Main content body */}
      <main className="flex-1 p-6 md:p-12 overflow-y-auto no-scrollbar max-w-7xl mx-auto flex flex-col gap-8">
        
        {/* Header */}
        <header className="flex justify-between items-center border-b border-[#424754]/10 pb-6">
          <div>
            <span className="text-xs font-bold font-mono text-[#adc6ff] uppercase tracking-widest bg-[#005ac2]/10 px-2.5 py-1 rounded-md">
              Sarah's Wellness Panel
            </span>
            <h1 className="text-3xl font-black font-display text-white mt-2">Sleep-Wake Coach Suite</h1>
            <p className="text-sm text-[#c2c6d6] font-light">Monitor patient clinical data and recommend cognitive wake programs.</p>
          </div>

          {/* Quick Stats */}
          <div className="hidden sm:flex gap-4">
            <div className="bg-[#10141a] px-5 py-2.5 border border-[#424754]/20 rounded-xl text-center min-w-[100px]">
              <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Patients</span>
              <h4 className="text-md font-bold text-[#adc6ff] mt-0.5">{clients.length} Active</h4>
            </div>
            <div className="bg-[#10141a] px-5 py-2.5 border border-[#424754]/20 rounded-xl text-center min-w-[100px]">
              <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Coaching Tips</span>
              <h4 className="text-md font-bold text-emerald-400 mt-0.5">{recommendations.length} Sent</h4>
            </div>
          </div>
        </header>

        {/* Mobile Nav */}
        <div className="md:hidden flex gap-2 border-b border-[#424754]/10 pb-4">
          <button
            onClick={() => setActiveTab('clients')}
            className={`flex-1 py-2.5 text-center rounded-lg font-bold text-xs ${
              activeTab === 'clients' ? "bg-blue-500/10 text-[#adc6ff] border border-blue-500/20" : "text-[#c2c6d6]"
            }`}
          >
            Clients ({clients.length})
          </button>
          <button
            onClick={() => setActiveTab('broadcast')}
            className={`flex-1 py-2.5 text-center rounded-lg font-bold text-xs ${
              activeTab === 'broadcast' ? "bg-blue-500/10 text-[#adc6ff] border border-blue-500/20" : "text-[#c2c6d6]"
            }`}
          >
            Broadcast
          </button>
          <button
            onClick={onLogout}
            className="px-3 text-[#ffb690] text-xs font-bold"
          >
            Exit
          </button>
        </div>

        {activeTab === 'clients' ? (
          <div className="flex flex-col gap-8 animate-fade-in">
            {/* Client summary table */}
            <div className="glass-card rounded-2xl border border-[#424754]/20 overflow-hidden shadow-2xl">
              <div className="p-5 border-b border-[#424754]/20 bg-[#161b22]/30 flex justify-between items-center">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display">Client Performance Roster</h3>
                <button className="text-[#adc6ff] hover:underline font-mono text-[10px] font-bold flex items-center gap-1">
                  <FileSpreadsheet className="w-4 h-4" /> EXPORT REPORT
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#c2c6d6] select-none font-sans">
                  <thead className="bg-[#10141a] border-b border-[#424754]/20 text-slate-400 font-mono uppercase font-bold">
                    <tr>
                      <th className="py-4 px-6">Patient Name</th>
                      <th className="py-4 px-6 text-center">Habit Score</th>
                      <th className="py-4 px-6 text-center">Active Streak</th>
                      <th className="py-4 px-6 text-center">Snooze Reduction</th>
                      <th className="py-4 px-6 text-center">Puzzle Accuracy</th>
                      <th className="py-4 px-6 text-center">Active Alarms</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#424754]/10">
                    {clients.map((c) => (
                      <tr key={c.id} className="hover:bg-[#161b22]/50 transition-colors">
                        <td className="py-4 px-6 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center font-bold text-blue-300">
                            {c.name.charAt(0)}
                          </div>
                          <div>
                            <span className="font-bold text-white block">{c.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono block">{c.email}</span>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-center font-bold font-mono text-white text-sm">
                          <span className={`px-2 py-0.5 rounded ${
                            c.habitScore >= 80 ? "bg-emerald-500/10 text-emerald-400" : "bg-orange-500/10 text-orange-400"
                          }`}>{c.habitScore}%</span>
                        </td>
                        <td className="py-4 px-6 text-center font-bold font-mono text-[#adc6ff] text-sm">{c.streak} Days</td>
                        <td className="py-4 px-6 text-center font-bold font-mono text-emerald-300">-{c.snoozeReduction}%</td>
                        <td className="py-4 px-6 text-center font-bold font-mono text-white">{c.accuracy}%</td>
                        <td className="py-4 px-6 text-center font-bold font-mono text-slate-400">{c.alarmsCount} set</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
            {/* Create suggestion form */}
            <div className="lg:col-span-5 glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col gap-5">
              <div>
                <h3 className="text-md font-bold text-white flex items-center gap-2">
                  <Send className="w-5 h-5 text-[#adc6ff]" /> Broadcast Sleep Plan Suggestion
                </h3>
                <p className="text-xs text-[#c2c6d6] mt-1">Submit customized instructions that propagate to the patient's home dashboard.</p>
              </div>

              <form onSubmit={handleBroadcast} className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-[#c2c6d6] uppercase tracking-wider">Plan Content</label>
                  <textarea
                    rows={4}
                    value={newRecommendation}
                    onChange={(e) => setNewRecommendation(e.target.value)}
                    placeholder="Try 15 mins of light math before your deep logic puzzles to improve speed and cognitive wakefulness."
                    className="bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3 text-white text-sm focus:border-[#adc6ff] focus:outline-none transition-colors leading-relaxed"
                    required
                  ></textarea>
                </div>

                {success && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-400 font-bold flex items-center gap-1.5 animate-fade-in">
                    <CheckCircle className="w-4 h-4" /> Plan broadcasted! Patients notified.
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full energy-gradient-bg hover:opacity-95 text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {submitting ? "Broadcasting..." : "Broadcast Recommendation"}
                </button>
              </form>
            </div>

            {/* Past broadcast history logs */}
            <div className="lg:col-span-7 glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col gap-5">
              <h3 className="text-xs font-bold text-[#adc6ff] uppercase tracking-widest font-mono">Past Broadcast History Logs</h3>
              <div className="flex flex-col gap-4 max-h-[350px] overflow-y-auto no-scrollbar pr-1">
                {recommendations.map((r) => (
                  <div key={r.id} className="p-4 bg-[#10141a]/60 border border-[#424754]/10 rounded-xl flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-slate-400 font-mono uppercase">Applied by patient: {r.applied ? "YES" : "AWAITING"}</span>
                      <span className="text-[10px] text-slate-400 font-mono font-bold">{r.date}</span>
                    </div>
                    <p className="text-xs text-white leading-relaxed font-light">{r.text}</p>
                  </div>
                ))}
                {recommendations.length === 0 && (
                  <p className="text-xs text-slate-500 py-6 text-center">No past sleep plans recorded.</p>
                )}
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
