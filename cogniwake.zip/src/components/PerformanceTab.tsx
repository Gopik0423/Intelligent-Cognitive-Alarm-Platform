import { PerformanceLog } from "../types";
import { TrendingUp, Award, Zap, Activity } from "lucide-react";

interface PerformanceTabProps {
  logs: PerformanceLog[];
}

export default function PerformanceTab({ logs }: PerformanceTabProps) {
  // Safe math calculations for averages
  const avgAccuracy = logs.length 
    ? Math.round(logs.reduce((acc, curr) => acc + curr.accuracy, 0) / logs.length) 
    : 0;

  const avgSolveTime = logs.length 
    ? Math.round(logs.reduce((acc, curr) => acc + curr.timeToSolve, 0) / logs.length) 
    : 0;

  const totalSnoozes = logs.reduce((acc, curr) => acc + curr.snoozesCount, 0);

  // SVG Drawing Helpers for Last 7 Logs Accuracy Line
  const width = 500;
  const height = 180;
  const padding = 25;
  const usableWidth = width - padding * 2;
  const usableHeight = height - padding * 2;

  // Generate coordinates for Accuracy Line
  const points = logs.map((log, index) => {
    const x = padding + (index / Math.max(1, logs.length - 1)) * usableWidth;
    // Map accuracy 0-100 to y coordinate (higher accuracy is lower Y coord)
    const y = padding + usableHeight - (log.accuracy / 100) * usableHeight;
    return { x, y, val: log.accuracy, label: log.date.split("-")[2] };
  });

  const pathD = points.length > 1
    ? points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')
    : '';

  const areaD = points.length > 1
    ? `${pathD} L ${points[points.length - 1].x} ${height - padding} L ${points[0].x} ${height - padding} Z`
    : '';

  return (
    <div className="flex flex-col gap-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            icon: <Zap className="w-5 h-5 text-[#adc6ff]" />,
            title: "Current Streak",
            val: "12 Days",
            desc: "Waking up consistently",
          },
          {
            icon: <Activity className="w-5 h-5 text-[#d0bcff]" />,
            title: "Avg Accuracy",
            val: `${avgAccuracy}%`,
            desc: "Prefrontal lobe accuracy",
          },
          {
            icon: <TrendingUp className="w-5 h-5 text-[#ffb690]" />,
            title: "Avg Wake-up Solve",
            val: `${avgSolveTime}s`,
            desc: "Speed to complete puzzle",
          },
          {
            icon: <Award className="w-5 h-5 text-emerald-400" />,
            title: "Total Snoozes Avoided",
            val: "32 Snoozes",
            desc: "Prevented sleep-interruption",
          }
        ].map((c, idx) => (
          <div key={idx} className="glass-card rounded-2xl p-5 border border-[#424754]/20">
            <div className="flex justify-between items-start mb-3">
              <span className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">{c.title}</span>
              <div className="w-8 h-8 rounded-lg bg-[#1c2026] flex items-center justify-center border border-[#424754]/30">{c.icon}</div>
            </div>
            <h4 className="text-2xl font-black text-white font-display mb-1">{c.val}</h4>
            <p className="text-[11px] text-[#c2c6d6] font-light leading-relaxed">{c.desc}</p>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* SVG Chart 1: Accuracy Curve */}
        <div className="glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col gap-4">
          <div>
            <h3 className="text-md font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#adc6ff]" /> COGNITIVE ACCURACY OVER TIME
            </h3>
            <p className="text-xs text-[#c2c6d6] mt-0.5">Average accuracy rating on initial puzzle answers over the last 7 days.</p>
          </div>

          <div className="w-full bg-[#10141a]/50 rounded-xl border border-[#424754]/20 p-4 relative flex justify-center">
            {logs.length > 1 ? (
              <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
                <defs>
                  <linearGradient id="chartGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#005ac2" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#571bc1" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid guidelines */}
                {[0.25, 0.5, 0.75, 1].map((ratio, i) => (
                  <line
                    key={i}
                    x1={padding}
                    y1={padding + usableHeight * (1 - ratio)}
                    x2={width - padding}
                    y2={padding + usableHeight * (1 - ratio)}
                    stroke="#424754"
                    strokeOpacity="0.1"
                    strokeWidth="1"
                    strokeDasharray="4"
                  />
                ))}

                {/* Smooth area fill */}
                <path d={areaD} fill="url(#chartGlow)" />

                {/* Accuracy Path */}
                <path d={pathD} fill="none" stroke="#adc6ff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

                {/* Point markers & Tooltips */}
                {points.map((p, idx) => (
                  <g key={idx} className="group cursor-pointer">
                    <circle cx={p.x} cy={p.y} r="4.5" fill="#10141a" stroke="#adc6ff" strokeWidth="2.5" />
                    {/* Tooltip bubble appearing on hover */}
                    <g className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <rect x={p.x - 20} y={p.y - 28} width="40" height="18" rx="4" fill="#1c2026" stroke="#424754" strokeWidth="1" />
                      <text x={p.x} y={p.y - 16} fontSize="9" fontWeight="bold" fill="#adc6ff" textAnchor="middle" fontFamily="monospace">
                        {p.val}%
                      </text>
                    </g>
                    {/* X-axis date labels */}
                    <text x={p.x} y={height - 5} fontSize="9" fill="#c2c6d6" textAnchor="middle" fontFamily="monospace">
                      {p.label}
                    </text>
                  </g>
                ))}
              </svg>
            ) : (
              <div className="h-40 flex items-center justify-center text-xs text-slate-500">Awaiting more data logs to graph trend.</div>
            )}
          </div>
        </div>

        {/* SVG Chart 2: Wake-up Speed & Snoozes */}
        <div className="glass-card rounded-2xl p-6 border border-[#424754]/20 flex flex-col gap-4">
          <div>
            <h3 className="text-md font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#d0bcff]" /> WAKE-UP SPEED & SNOOZES
            </h3>
            <p className="text-xs text-[#c2c6d6] mt-0.5">Solve speed (bars, seconds) mapped against snooze triggers (pills) daily.</p>
          </div>

          <div className="w-full bg-[#10141a]/50 rounded-xl border border-[#424754]/20 p-4 relative flex justify-center">
            {logs.length > 0 ? (
              <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
                {/* Horizontal Guidelines */}
                {[0.25, 0.5, 0.75, 1].map((ratio, i) => (
                  <line
                    key={i}
                    x1={padding}
                    y1={padding + usableHeight * (1 - ratio)}
                    x2={width - padding}
                    y2={padding + usableHeight * (1 - ratio)}
                    stroke="#424754"
                    strokeOpacity="0.1"
                    strokeWidth="1"
                    strokeDasharray="4"
                  />
                ))}

                {/* Draw custom bars */}
                {logs.map((log, index) => {
                  const x = padding + (index / Math.max(1, logs.length - 1)) * usableWidth;
                  
                  // Map seconds (max 60 scale for display)
                  const barHeight = (Math.min(log.timeToSolve, 60) / 60) * usableHeight;
                  const barY = padding + usableHeight - barHeight;
                  const barWidth = 14;

                  return (
                    <g key={index} className="group cursor-pointer">
                      {/* Solve time bar */}
                      <rect
                        x={x - barWidth / 2}
                        y={barY}
                        width={barWidth}
                        height={barHeight}
                        rx="4"
                        fill="url(#barGradient)"
                        className="opacity-80 group-hover:opacity-100 transition-opacity"
                      />

                      {/* Pill display for Snoozes */}
                      {log.snoozesCount > 0 && (
                        <circle
                          cx={x}
                          cy={barY - 12}
                          r="5.5"
                          fill="#ffb690"
                          stroke="#10141a"
                          strokeWidth="1.5"
                        />
                      )}

                      {/* Tooltip */}
                      <g className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <rect x={x - 30} y={barY - 38} width="60" height="20" rx="4" fill="#1c2026" stroke="#424754" strokeWidth="1" />
                        <text x={x} y={barY - 25} fontSize="8" fontWeight="bold" fill="white" textAnchor="middle" fontFamily="monospace">
                          {log.timeToSolve}s | {log.snoozesCount}z
                        </text>
                      </g>

                      {/* X Axis */}
                      <text x={x} y={height - 5} fontSize="9" fill="#c2c6d6" textAnchor="middle" fontFamily="monospace">
                        {log.date.split("-")[2]}
                      </text>
                    </g>
                  );
                })}

                {/* Bar Gradient Definition */}
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#d0bcff" />
                    <stop offset="100%" stopColor="#571bc1" />
                  </linearGradient>
                </defs>
              </svg>
            ) : (
              <div className="h-40 flex items-center justify-center text-xs text-slate-500">Awaiting more data logs to graph performance.</div>
            )}
          </div>
        </div>

      </div>

      {/* Historical Data Table */}
      <div className="glass-card rounded-2xl border border-[#424754]/20 overflow-hidden">
        <div className="p-5 border-b border-[#424754]/10 bg-[#161b22]/40">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider font-display">Daily Wake-up Audit Ledger</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#c2c6d6] select-none font-sans">
            <thead className="bg-[#10141a]/60 text-slate-400 font-mono uppercase font-bold border-b border-[#424754]/20">
              <tr>
                <th className="py-4 px-6">Wake Date</th>
                <th className="py-4 px-6">Cognitive Accuracy</th>
                <th className="py-4 px-6">Wake duration</th>
                <th className="py-4 px-6">Snoozes Count</th>
                <th className="py-4 px-6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#424754]/10">
              {logs.map((log, idx) => (
                <tr key={idx} className="hover:bg-[#1c2026]/40 transition-colors">
                  <td className="py-4 px-6 font-mono font-bold text-white">{log.date}</td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-[#1c2026] rounded-full overflow-hidden border border-white/5">
                        <div className="h-full bg-blue-400 rounded-full" style={{ width: `${log.accuracy}%` }}></div>
                      </div>
                      <span className="font-mono font-bold text-white">{log.accuracy}%</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 font-mono font-bold text-[#adc6ff]">{log.timeToSolve} seconds</td>
                  <td className="py-4 px-6 font-mono font-bold text-[#ffb690]">{log.snoozesCount} times</td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      log.snoozesCount === 0 
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                        : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                    }`}>
                      {log.snoozesCount === 0 ? "OPTIMAL RISE" : "SNOOZED"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
