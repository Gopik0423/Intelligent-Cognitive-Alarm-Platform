import { useState, useEffect, useRef } from "react";
import { Brain, Volume2, AlertTriangle, CheckCircle, ShieldAlert, Cpu, Sparkles } from "lucide-react";
import { Puzzle } from "../types";

interface AlarmActiveOverlayProps {
  alarmId: string;
  challengeType: 'math' | 'memory' | 'sequence' | 'word' | 'reaction' | 'logic' | 'stroop';
  difficulty: 'easy' | 'medium' | 'hard';
  sound: string;
  onDismiss: (stats: { accuracy: number; snoozes: number; timeToSolve: number }) => void;
}

export default function AlarmActiveOverlay({
  alarmId,
  challengeType,
  difficulty,
  sound,
  onDismiss,
}: AlarmActiveOverlayProps) {
  const [puzzle, setPuzzle] = useState<Puzzle | null>(null);
  const [loading, setLoading] = useState(true);
  const [attempts, setAttempts] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [feedback, setFeedback] = useState("");
  const [snoozes, setSnoozes] = useState(0);
  const [timer, setTimer] = useState(0);
  const [isDismissed, setIsDismissed] = useState(false);
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalIdRef = useRef<number | null>(null);
  const timerIdRef = useRef<number | null>(null);

  // Synthesize custom gentle chime
  const playChime = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      // Create synthetic major chord chime sequence
      const now = ctx.currentTime;
      const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5 major chord
      
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        // Triangle wave for smooth, flute-like peaceful tone
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.15);
        
        // Volume envelope (quiet, fade out)
        gain.gain.setValueAtTime(0, now + idx * 0.15);
        gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.15 + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.15 + 1.2);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now + idx * 0.15);
        osc.stop(now + idx * 0.15 + 1.5);
      });
    } catch (err) {
      console.warn("Audio Context error:", err);
    }
  };

  // Start sound loop
  useEffect(() => {
    // Play immediately and then repeat every 3 seconds
    playChime();
    intervalIdRef.current = window.setInterval(playChime, 3200);

    // Track total solve duration
    timerIdRef.current = window.setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);

    return () => {
      if (intervalIdRef.current) clearInterval(intervalIdRef.current);
      if (timerIdRef.current) clearInterval(timerIdRef.current);
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  // Fetch puzzle from API
  useEffect(() => {
    const fetchPuzzle = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/challenges/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: challengeType, difficulty }),
        });
        const data = await response.json();
        setPuzzle(data);
      } catch (err) {
        console.error("Failed to load puzzle:", err);
        // Instant local backup puzzle
        setPuzzle({
          id: "local-m-99",
          type: "math",
          question: "Solve: (12 * 5) - 18",
          options: ["42", "38", "52", "48"],
          correctAnswer: "42",
          hint: "12 times 5 is 60, then subtract 18.",
          explanation: "60 - 18 = 42"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPuzzle();
  }, [alarmId, challengeType, difficulty]);

  const handleAnswerSubmit = (ans: string) => {
    if (!puzzle) return;
    setSelectedAnswer(ans);
    setAttempts((prev) => prev + 1);

    if (ans === puzzle.correctAnswer) {
      // Clear interval and stop sounds
      if (intervalIdRef.current) clearInterval(intervalIdRef.current);
      setFeedback("CORRECT! Prefrontal lobe fully active.");
      setIsDismissed(true);
    } else {
      setFeedback("INCORRECT. Sleep chemicals still blocking signals. Try again!");
      // Pulse audio immediately as a gentle alert
      playChime();
    }
  };

  const handleSnooze = () => {
    setSnoozes((prev) => prev + 1);
    setFeedback("Snoozed for 3 minutes! Solving practice puzzles will wake you up faster.");
    playChime();
    
    // Simulate snooze by reloading a new puzzle
    setLoading(true);
    setTimeout(async () => {
      try {
        const response = await fetch("/api/challenges/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: challengeType, difficulty }),
        });
        const data = await response.json();
        setPuzzle(data);
      } catch (err) {
        console.error("Failed to reload puzzle on snooze:", err);
      } finally {
        setLoading(false);
      }
    }, 500);
  };

  const handleFinish = () => {
    const accuracy = Math.round(attempts === 0 ? 100 : (1 / attempts) * 100);
    onDismiss({
      accuracy,
      snoozes,
      timeToSolve: timer,
    });
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#0A0E14] flex flex-col items-center justify-center p-6 text-[#dfe2eb] select-none font-sans overflow-y-auto no-scrollbar">
      
      {/* Absolute ambient neon elements */}
      <div className="absolute top-1/4 left-1/4 w-[350px] h-[350px] bg-red-500/5 rounded-full blur-[100px] pointer-events-none animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[350px] h-[350px] bg-[#571bc1]/10 rounded-full blur-[100px] pointer-events-none animate-pulse"></div>

      <div className="w-full max-w-xl text-center flex flex-col gap-8 relative z-10 my-auto">
        
        {/* Animated Header */}
        {!isDismissed ? (
          <div className="flex flex-col items-center gap-3">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center animate-bounce">
              <ShieldAlert className="w-9 h-9 text-red-400" />
            </div>
            <div className="text-red-400 font-mono text-sm uppercase tracking-widest font-bold flex items-center gap-2">
              <Volume2 className="w-4 h-4 animate-ping" /> ALARM RINGING
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mt-1 text-white">Wake Up Your Mind!</h2>
            <p className="text-[#c2c6d6] text-sm font-light max-w-sm">
              Your streak of <span className="text-[#adc6ff] font-bold">12 days</span> is at stake. Solve this challenge to dismiss.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              <CheckCircle className="w-9 h-9 text-emerald-400" />
            </div>
            <span className="text-emerald-400 font-mono text-sm uppercase tracking-widest font-bold">SUCCESSFULLY COGNIZANT</span>
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mt-1 text-white">Rise and Shine!</h2>
            <p className="text-emerald-300 text-sm">Prefrontal lobe fully activated in {timer}s!</p>
          </div>
        )}

        {/* Puzzle Card */}
        <div className="bg-[#10141a]/90 border border-[#424754]/30 rounded-3xl p-6 md:p-8 shadow-2xl backdrop-blur-md relative overflow-hidden">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-4">
              <div className="w-10 h-10 border-4 border-blue-500/20 border-t-blue-400 rounded-full animate-spin"></div>
              <p className="text-xs font-mono text-[#adc6ff] uppercase tracking-widest font-bold flex items-center gap-1.5">
                <Cpu className="w-4 h-4 animate-spin" /> Fetching AI-Powered Challenge...
              </p>
            </div>
          ) : !isDismissed && puzzle ? (
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="text-xs font-bold font-mono text-[#adc6ff] uppercase bg-[#adc6ff]/10 px-2.5 py-1 rounded-md border border-blue-500/20 flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5" /> {puzzle.type} puzzle
                </span>
                <span className="text-xs font-bold font-mono text-[#ffb690] uppercase bg-[#ffb690]/10 px-2.5 py-1 rounded-md border border-orange-500/20">
                  {difficulty}
                </span>
              </div>

              {/* Question Text */}
              <p className="text-lg md:text-xl font-bold text-white mb-8 font-sans leading-relaxed whitespace-pre-line">
                {puzzle.question}
              </p>

              {/* MCQ Options */}
              <div className="grid grid-cols-1 gap-3.5">
                {puzzle.options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAnswerSubmit(option)}
                    className={`w-full py-4 px-6 rounded-xl font-sans text-md font-bold text-left border transition-all cursor-pointer flex justify-between items-center ${
                      selectedAnswer === option
                        ? option === puzzle.correctAnswer
                          ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                          : "bg-red-500/20 border-red-500 text-red-400"
                        : "bg-[#1c2026] border-[#424754]/50 text-[#dfe2eb] hover:bg-[#353940]/50 hover:border-[#adc6ff]/40"
                    }`}
                  >
                    <span>{option}</span>
                    {selectedAnswer === option && (
                      option === puzzle.correctAnswer ? (
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-red-400" />
                      )
                    )}
                  </button>
                ))}
              </div>

              {/* Feedback Message */}
              {feedback && (
                <div className={`mt-6 text-sm font-semibold p-3.5 rounded-xl border ${
                  selectedAnswer === puzzle.correctAnswer
                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                    : "bg-red-500/10 border-red-500/20 text-red-300"
                }`}>
                  {feedback}
                </div>
              )}

              {/* Hint option if struggling */}
              {attempts >= 1 && (
                <div className="mt-4 text-xs font-mono text-[#c2c6d6] italic text-left px-2 bg-[#1c2026]/40 py-2 rounded-lg border border-dashed border-[#424754]/30">
                  💡 Hint: {puzzle.hint}
                </div>
              )}
            </div>
          ) : (
            <div className="py-8">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-6">
                <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
                <span className="text-xs font-mono text-emerald-300 uppercase tracking-widest font-bold">Initial state: 100% alertness</span>
              </div>
              <h4 className="text-xl font-display font-bold text-white mb-4">You are ready to seize the day!</h4>
              <div className="space-y-3 max-w-sm mx-auto text-left py-4 px-6 bg-[#161b22] border border-[#424754]/20 rounded-xl mb-6">
                <div className="flex justify-between text-xs">
                  <span className="text-[#c2c6d6]">Accuracy Score:</span>
                  <span className="text-emerald-400 font-mono font-bold">{Math.round(attempts === 0 ? 100 : (1 / attempts) * 100)}%</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#c2c6d6]">Snoozes Logged:</span>
                  <span className="text-[#ffb690] font-mono font-bold">{snoozes}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#c2c6d6]">Total Active Time:</span>
                  <span className="text-[#adc6ff] font-mono font-bold">{timer}s</span>
                </div>
              </div>
              <button
                onClick={handleFinish}
                className="energy-gradient-bg text-white font-bold text-md px-10 py-3.5 rounded-full hover:shadow-[0_0_20px_rgba(173,198,255,0.4)] transition-all cursor-pointer transform hover:scale-95"
              >
                Enter Dashboard
              </button>
            </div>
          )}
        </div>

        {/* Footer actions when alarm is active */}
        {!isDismissed && !loading && (
          <div className="flex items-center justify-center gap-6 text-[#c2c6d6] text-xs">
            <button
              onClick={handleSnooze}
              className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-full border border-white/10 font-bold tracking-wider hover:text-orange-300 transition-colors cursor-pointer"
            >
              😴 SNOOZE ALARM ({snoozes}/3)
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
