import React, { useState, FormEvent } from "react";
import { Clock, Plus, Trash2, ToggleLeft, ToggleRight, Play, Sparkles, Sliders, Volume2 } from "lucide-react";
import { Alarm } from "../types";

interface AlarmsTabProps {
  alarms: Alarm[];
  onToggleAlarm: (id: string, isActive: boolean) => void;
  onAddAlarm: (alarm: Omit<Alarm, "id" | "isActive">) => void;
  onDeleteAlarm: (id: string) => void;
  onSimulateAlarm: (alarm: Alarm) => void;
}

export default function AlarmsTab({
  alarms,
  onToggleAlarm,
  onAddAlarm,
  onDeleteAlarm,
  onSimulateAlarm,
}: AlarmsTabProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [time, setTime] = useState("07:00");
  const [days, setDays] = useState<string[]>(["Weekdays"]);
  const [challengeType, setChallengeType] = useState<Alarm["challengeType"]>("math");
  const [difficulty, setDifficulty] = useState<Alarm["difficulty"]>("medium");
  const [sound, setSound] = useState("chime");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddAlarm({
      time,
      days,
      challengeType,
      difficulty,
      sound,
    });
    setShowAddForm(false);
    // Reset values
    setTime("07:00");
    setDays(["Weekdays"]);
    setChallengeType("math");
    setDifficulty("medium");
    setSound("chime");
  };

  const dayOptions = [
    "Weekdays",
    "Weekends",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  const toggleDaySelection = (day: string) => {
    if (day === "Weekdays") {
      setDays(["Weekdays"]);
    } else if (day === "Weekends") {
      setDays(["Weekends"]);
    } else {
      // Remove Weekdays/Weekends if individual day is chosen
      const filtered = days.filter(d => d !== "Weekdays" && d !== "Weekends");
      if (filtered.includes(day)) {
        setDays(filtered.filter(d => d !== day));
      } else {
        setDays([...filtered, day]);
      }
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold font-display text-white">Alarm Management</h2>
          <p className="text-sm text-[#c2c6d6]">Set, edit, and simulate your active waking circuits.</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="energy-gradient-bg hover:opacity-95 text-white px-5 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-[#005ac2]/10 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Alarm
        </button>
      </header>

      {/* Add New Alarm Form */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-6 border border-[#424754]/30 flex flex-col gap-6 animate-fade-in">
          <div className="flex justify-between items-center pb-3 border-b border-[#424754]/20">
            <h3 className="text-md font-bold text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#adc6ff]" /> Configure New Wake Circle
            </h3>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-[#c2c6d6] hover:text-white text-xs font-semibold"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Alarm Time */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Time</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3.5 text-white font-mono text-xl focus:border-[#adc6ff] focus:outline-none transition-colors"
                required
              />
            </div>

            {/* AI Challenge Type */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Cognitive Task</label>
              <select
                value={challengeType}
                onChange={(e) => setChallengeType(e.target.value as Alarm["challengeType"])}
                className="bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3.5 text-white text-sm focus:border-[#adc6ff] focus:outline-none transition-colors"
              >
                <option value="math">🧮 Prefrontal Arithmetic (Math)</option>
                <option value="memory">🧩 Grid Memory Sequence</option>
                <option value="sequence">🔢 Logical Pattern Completion</option>
                <option value="word">🔤 Anagram Word Unscramble</option>
                <option value="reaction">⚡ Fast Reaction Response Test</option>
                <option value="logic">🧠 Syllogism & Logic Riddle</option>
                <option value="stroop">🌈 Stroop Color-Word Conflict</option>
              </select>
            </div>

            {/* Difficulty Level */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Cognitive Difficulty</label>
              <div className="flex gap-2">
                {(["easy", "medium", "hard"] as const).map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setDifficulty(diff)}
                    className={`flex-1 py-3 px-4 rounded-xl border text-xs font-bold uppercase transition-all cursor-pointer ${
                      difficulty === diff
                        ? "bg-[#005ac2]/20 border-[#adc6ff] text-[#adc6ff] shadow-inner"
                        : "bg-[#1c2026] border-[#424754]/40 text-[#c2c6d6] hover:bg-[#353940]/30"
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Gentle Chime Selection */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Wake Sound</label>
              <select
                value={sound}
                onChange={(e) => setSound(e.target.value)}
                className="bg-[#1c2026] border border-[#424754]/50 rounded-xl px-4 py-3.5 text-white text-sm focus:border-[#adc6ff] focus:outline-none transition-colors"
              >
                <option value="chime">🎵 Peace Wave (Major Chords)</option>
                <option value="ambient">🧘 Gentle Cosmic Swell</option>
                <option value="radar">📡 Pulsating Radar Ping</option>
                <option value="digital">⏰ Retro High Frequency Buzz</option>
              </select>
            </div>
          </div>

          {/* Day selection */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-bold text-[#c2c6d6] uppercase tracking-wider">Repeat Days</label>
            <div className="flex flex-wrap gap-2">
              {dayOptions.map((day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => toggleDaySelection(day)}
                  className={`py-2 px-3.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
                    days.includes(day)
                      ? "bg-gradient-to-r from-[#005ac2] to-[#571bc1] border-transparent text-white shadow-lg"
                      : "bg-[#1c2026] border-[#424754]/40 text-[#c2c6d6] hover:bg-[#353940]/30"
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full energy-gradient-bg hover:opacity-95 text-white font-bold py-3.5 rounded-xl text-sm transition-opacity shadow-lg shadow-blue-500/10 cursor-pointer mt-2"
          >
            Create Alarm
          </button>
        </form>
      )}

      {/* Alarms Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {alarms.map((alarm) => (
          <div
            key={alarm.id}
            className={`glass-card rounded-2xl p-6 border transition-all duration-300 relative overflow-hidden group ${
              alarm.isActive 
                ? "border-blue-500/20 shadow-lg shadow-blue-500/5 hover:border-blue-500/40" 
                : "opacity-60 border-[#424754]/20 hover:opacity-90"
            }`}
          >
            {/* Dynamic vertical lightbar for active alarms */}
            {alarm.isActive && (
              <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#005ac2] to-[#571bc1] shadow-[0_0_15px_rgba(173,198,255,0.8)]"></div>
            )}

            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                  alarm.isActive ? "bg-blue-500/10 border-blue-500/30 text-[#adc6ff]" : "bg-[#1c2026] border-[#424754]/30 text-slate-500"
                }`}>
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`text-2xl md:text-3xl font-bold font-mono tracking-tight ${alarm.isActive ? "text-white" : "text-slate-400"}`}>
                    {alarm.time}
                  </h3>
                  <span className="text-xs font-semibold text-[#c2c6d6]">
                    {alarm.days.join(", ")}
                  </span>
                </div>
              </div>

              {/* Toggle Switch */}
              <button
                onClick={() => onToggleAlarm(alarm.id, !alarm.isActive)}
                className="text-white hover:opacity-90 transition-all cursor-pointer bg-transparent border-none outline-none"
              >
                {alarm.isActive ? (
                  <ToggleRight className="w-12 h-12 text-[#adc6ff] drop-shadow-[0_0_8px_rgba(173,198,255,0.4)]" />
                ) : (
                  <ToggleLeft className="w-12 h-12 text-slate-500" />
                )}
              </button>
            </div>

            {/* Task Info Row */}
            <div className="mt-4 flex flex-wrap gap-2 pt-4 border-t border-[#424754]/10 items-center justify-between">
              <div className="flex gap-2">
                <span className="text-[11px] font-mono font-bold uppercase bg-[#1c2026] border border-[#424754]/30 text-[#c2c6d6] px-2 py-1 rounded-md flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-[#adc6ff]" /> {alarm.challengeType}
                </span>
                <span className="text-[11px] font-mono font-bold uppercase bg-[#1c2026] border border-[#424754]/30 text-[#ffb690] px-2 py-1 rounded-md">
                  {alarm.difficulty}
                </span>
                <span className="text-[11px] font-mono font-bold uppercase bg-[#1c2026] border border-[#424754]/30 text-slate-400 px-2 py-1 rounded-md flex items-center gap-1">
                  <Volume2 className="w-3 h-3" /> {alarm.sound}
                </span>
              </div>

              {/* Action buttons */}
              <div className="flex gap-1">
                {alarm.isActive && (
                  <button
                    onClick={() => onSimulateAlarm(alarm)}
                    title="Simulate Wake Up Challenge Trigger"
                    className="p-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg hover:scale-105 transition-all flex items-center gap-1 font-mono text-[10px] font-bold cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5" /> Trigger
                  </button>
                )}
                <button
                  onClick={() => onDeleteAlarm(alarm.id)}
                  title="Delete Wake Circle"
                  className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-lg hover:scale-105 transition-all cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {alarms.length === 0 && (
          <div className="col-span-1 md:col-span-2 py-12 text-center glass-card rounded-2xl border border-dashed border-[#424754]/30">
            <Clock className="w-10 h-10 text-slate-500 mx-auto mb-3" />
            <h4 className="font-display font-bold text-white text-md mb-1">No wake circles configured</h4>
            <p className="text-xs text-[#c2c6d6] max-w-xs mx-auto">Create an alarm schedule above and connect it with an AI puzzle to begin.</p>
          </div>
        )}
      </div>
    </div>
  );
}
