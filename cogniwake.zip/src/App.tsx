import { useState, useEffect, useRef } from "react";
import { User, Alarm } from "./types";
import LandingPage from "./components/LandingPage";
import AuthPage from "./components/AuthPage";
import Dashboard from "./components/Dashboard";
import CoachDashboard from "./components/CoachDashboard";
import AlarmActiveOverlay from "./components/AlarmActiveOverlay";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<'landing' | 'auth' | 'app'>('landing');
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [activeAlarm, setActiveAlarm] = useState<Alarm | null>(null);
  
  const lastTriggeredMinRef = useRef<string>("");

  // Restore session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("cogniwake_user");
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setCurrentUser(user);
        setView('app');
      } catch (err) {
        console.error("Failed to parse stored user:", err);
      }
    }
  }, []);

  // Load alarms from server
  const loadAlarms = async () => {
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      const storedToken = localStorage.getItem("cogniwake_token");
      if (storedToken) {
        headers["Authorization"] = `Bearer ${storedToken}`;
      }
      const response = await fetch("/api/alarms", { headers });
      const data = await response.json();
      setAlarms(data);
    } catch (err) {
      console.error("Failed to load alarms from server:", err);
    }
  };

  // Sync alarms on initial load and when user changes
  useEffect(() => {
    if (currentUser) {
      loadAlarms();
    }
  }, [currentUser]);

  // Clock ticks to check alarm schedules in real-time
  useEffect(() => {
    const checkSchedule = () => {
      if (activeAlarm || alarms.length === 0) return;

      const now = new Date();
      const currentHrMin = now.toTimeString().slice(0, 5); // "HH:MM"
      
      // Avoid triggering multiple times in the same minute
      if (lastTriggeredMinRef.current === currentHrMin) return;

      const currentDayIndex = now.getDay(); // 0 is Sunday, 1 is Monday...
      const daysMap = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      const currentDayName = daysMap[currentDayIndex];
      const isWeekend = currentDayIndex === 0 || currentDayIndex === 6;
      const isWeekday = !isWeekend;

      alarms.forEach((alarm) => {
        if (alarm.isActive && alarm.time === currentHrMin) {
          const daysMatch = alarm.days.some((d) => {
            if (d === "Weekdays") return isWeekday;
            if (d === "Weekends") return isWeekend;
            return d.toLowerCase() === currentDayName.toLowerCase();
          });

          if (daysMatch) {
            lastTriggeredMinRef.current = currentHrMin;
            setActiveAlarm(alarm);
          }
        }
      });
    };

    // Check every 10 seconds
    const intervalId = setInterval(checkSchedule, 10000);
    return () => clearInterval(intervalId);
  }, [alarms, activeAlarm]);

  // Auth Callbacks
  const handleAuthSuccess = (userData: User & { token?: string }) => {
    setCurrentUser(userData);
    localStorage.setItem("cogniwake_user", JSON.stringify(userData));
    if (userData.token) {
      localStorage.setItem("cogniwake_token", userData.token);
    }
    setView('app');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("cogniwake_user");
    localStorage.removeItem("cogniwake_token");
    setView('landing');
  };

  // Alarm Mutations
  const handleToggleAlarm = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/alarms/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive })
      });
      const updated = await response.json();
      setAlarms(prev => prev.map(a => a.id === id ? updated : a));
    } catch (err) {
      console.error(err);
      // Fallback
      setAlarms(prev => prev.map(a => a.id === id ? { ...a, isActive } : a));
    }
  };

  const handleAddAlarm = async (alarmConfig: Omit<Alarm, "id" | "isActive">) => {
    try {
      const response = await fetch("/api/alarms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(alarmConfig)
      });
      const newAlarm = await response.json();
      setAlarms(prev => [...prev, newAlarm]);
    } catch (err) {
      console.error(err);
      // Fallback
      const newAlarm: Alarm = {
        id: `alarm-${Date.now()}`,
        isActive: true,
        ...alarmConfig
      };
      setAlarms(prev => [...prev, newAlarm]);
    }
  };

  const handleDeleteAlarm = async (id: string) => {
    try {
      await fetch(`/api/alarms/${id}`, { method: "DELETE" });
      setAlarms(prev => prev.filter(a => a.id !== id));
    } catch (err) {
      console.error(err);
      // Fallback
      setAlarms(prev => prev.filter(a => a.id !== id));
    }
  };

  const handleUpdateUser = async (updatedFields: Partial<User>) => {
    if (!currentUser) return;
    try {
      const response = await fetch("/api/auth/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedFields)
      });
      const updatedUser = await response.json();
      setCurrentUser(updatedUser);
      localStorage.setItem("cogniwake_user", JSON.stringify(updatedUser));
    } catch (err) {
      console.error("Failed to update profile:", err);
      // Fallback
      const newUser = { ...currentUser, ...updatedFields };
      setCurrentUser(newUser);
      localStorage.setItem("cogniwake_user", JSON.stringify(newUser));
    }
  };

  const handleAlarmDismiss = async (stats: { accuracy: number; snoozes: number; timeToSolve: number }) => {
    setActiveAlarm(null);
    // Log the wake results back to the server performance ledger
    try {
      await fetch("/api/performance/log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accuracy: stats.accuracy,
          snoozesCount: stats.snoozes,
          timeToSolve: stats.timeToSolve
        })
      });
    } catch (err) {
      console.error("Failed to log wakeup performance stats:", err);
    }
  };

  return (
    <div className="bg-[#0A0E14] text-[#dfe2eb] min-h-screen">
      {/* 1. View Routing Router */}
      {view === 'landing' && (
        <LandingPage
          onGetStarted={() => setView('auth')}
          onLoginClick={() => setView('auth')}
        />
      )}

      {view === 'auth' && (
        <AuthPage
          onAuthSuccess={handleAuthSuccess}
          onBackToHome={() => setView('landing')}
        />
      )}

      {view === 'app' && currentUser && (
        currentUser.role === 'coach' ? (
          <CoachDashboard onLogout={handleLogout} />
        ) : (
          <Dashboard
            user={currentUser}
            onLogout={handleLogout}
            onSimulateAlarm={(alarm) => setActiveAlarm(alarm)}
            alarms={alarms}
            onToggleAlarm={handleToggleAlarm}
            onAddAlarm={handleAddAlarm}
            onDeleteAlarm={handleDeleteAlarm}
            onUpdateUser={handleUpdateUser}
          />
        )
      )}

      {/* 2. Active Alarm Overlay Portal */}
      {activeAlarm && (
        <AlarmActiveOverlay
          alarmId={activeAlarm.id}
          challengeType={activeAlarm.challengeType}
          difficulty={activeAlarm.difficulty}
          sound={activeAlarm.sound}
          onDismiss={handleAlarmDismiss}
        />
      )}
    </div>
  );
}
